"""
actions/iphone.py — connect to an iPhone, only after the owner accepts on the phone.

How consent works: the first time, `pair` makes the iPhone show "Trust This
Computer?". Nothing is shared until the owner taps Trust and enters the passcode.
Revoke any time on the phone: Settings > General > Transfer or Reset iPhone >
Reset > Reset Location & Privacy.

What Apple allows once trusted (this tool does all of it):
  status / info / battery, list and copy photos and videos (DCIM), browse, copy,
  upload and delete files in the phone's media area, list installed apps,
  screenshots and launching apps (need Developer Mode on the phone).
What Apple does NOT allow from any computer, so this tool cannot do it:
  tapping or typing on the phone, reading other apps' private data, placing
  WhatsApp / Messenger / Instagram calls, sending iMessages.
Phone calls and SMS from a Windows PC go through Microsoft Phone Link (Bluetooth),
see action=call and action=phone_link.

Needs:  pip install pymobiledevice3   and, on Windows, Apple Devices (or iTunes)
installed so the USB driver exists. Wi-Fi connection works after one USB pairing
(action=wifi_on).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

_NOWIN = 0x08000000 if sys.platform == "win32" else 0
_NUM = re.compile(r"^\+?[0-9][0-9 ()\-]{4,18}$")


def _pmd(*args: str, timeout: int = 90) -> tuple[bool, str]:
    try:
        r = subprocess.run([sys.executable, "-m", "pymobiledevice3", *args],
                           capture_output=True, text=True, timeout=timeout,
                           creationflags=_NOWIN)
    except subprocess.TimeoutExpired:
        return False, "Timed out. If the iPhone is showing a Trust prompt, accept it and try again."
    except Exception as e:
        return False, str(e)
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    if "No module named pymobiledevice3" in out:
        return False, "Missing package. Run: pip install pymobiledevice3"
    return r.returncode == 0, out


def _explain(out: str) -> str:
    low = out.lower()
    if "no device" in low or "not connected" in low or "nodeviceconnected" in low.replace(" ", ""):
        return ("No iPhone found. Plug it in with the cable, unlock it, install Apple Devices "
                "(or iTunes) on this PC, and try again.")
    if "pairing" in low or "trust" in low or "passwordprotected" in low.replace(" ", "") or "locked" in low:
        return ("The iPhone has not accepted this computer. Unlock it, tap Trust on the prompt, "
                "enter the passcode, then ask me again. " + out[-160:])
    return out[-600:] or "No output."


def _devices() -> list[dict]:
    ok, out = _pmd("usbmux", "list", timeout=30)
    if not ok:
        return []
    try:
        data = json.loads(out[out.index("["):])
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _status() -> str:
    ds = _devices()
    if not ds:
        ok, out = _pmd("usbmux", "list", timeout=30)
        return _explain(out) if not ok else "No iPhone connected. Plug it in, unlock it, and try again."
    d = ds[0]
    name = d.get("DeviceName") or d.get("ProductType") or "iPhone"
    return (f"Connected: {name} (iOS {d.get('ProductVersion', '?')}) over "
            f"{d.get('ConnectionType', 'USB')}.")


def _safe_remote(path: str) -> str:
    p = "/" + (path or "").replace("\\", "/").strip("/")
    return "/" if p == "/" else re.sub(r"/{2,}", "/", p)


def _dest(path: str, default_name: str) -> Path:
    base = Path(path).expanduser() if path else Path.home() / "Downloads" / "iPhone"
    base.mkdir(parents=True, exist_ok=True) if not base.suffix else base.parent.mkdir(parents=True, exist_ok=True)
    return base


def _phone_link() -> str:
    if sys.platform != "win32":
        return "Phone Link is a Windows app. On a Mac, use FaceTime/iPhone Continuity."
    try:
        subprocess.Popen(["explorer.exe", r"shell:AppsFolder\Microsoft.YourPhone_8wekyb3d8bbwe!App"],
                         creationflags=_NOWIN)
        return ("Opened Phone Link. Link your iPhone there once (it shows a code to confirm on the "
                "phone and asks for Bluetooth permission); after that calls and messages can go through it.")
    except Exception as e:
        return f"Could not open Phone Link: {e}"


def _call(number: str) -> str:
    n = re.sub(r"[ ()\-]", "", number or "")
    if not _NUM.match(number or ""):
        return "I need a valid phone number to call."
    try:
        if sys.platform == "win32":
            os.startfile(f"tel:{n}")                           # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", f"tel:{n}"])
        else:
            subprocess.Popen(["xdg-open", f"tel:{n}"])
    except Exception as e:
        return f"NOT started: {e}"
    return (f"Handed {n} to this computer's phone app (Phone Link on Windows). I cannot see whether "
            f"the call connected; if nothing appeared, link the iPhone in Phone Link first.")


def iphone(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "status")).lower().strip()
    path = str(parameters.get("path", "") or "")
    dest = str(parameters.get("dest", "") or "")
    if player:
        try:
            player.write_log(f"[iphone] {a}")
        except Exception:
            pass

    if a == "status":
        return _status()
    if a == "pair":
        ok, out = _pmd("lockdown", "pair", timeout=120)
        return ("Paired. The iPhone accepted this computer." if ok else _explain(out))
    if a == "wifi_on":
        ok, out = _pmd("lockdown", "wifi-connections", "on")
        return "Wi-Fi connection enabled for this iPhone (it must be on the same network)." if ok else _explain(out)
    if a == "info":
        ok, out = _pmd("lockdown", "info")
        return out[:3000] if ok else _explain(out)
    if a == "battery":
        ok, out = _pmd("diagnostics", "battery", "single")
        return out[:800] if ok else _explain(out)
    if a in ("ls", "list_files"):
        ok, out = _pmd("afc", "ls", _safe_remote(path or "/"))
        return out[:4000] if ok else _explain(out)
    if a in ("photos", "list_photos"):
        ok, out = _pmd("afc", "ls", _safe_remote(path or "/DCIM"))
        return out[:4000] if ok else _explain(out)
    if a in ("pull", "download", "get_photo"):
        if not path:
            return "Which file? Give its path on the iPhone, e.g. /DCIM/100APPLE/IMG_0001.JPG"
        d = _dest(dest, Path(path).name)
        target = d / Path(path).name if d.is_dir() or not d.suffix else d
        ok, out = _pmd("afc", "pull", _safe_remote(path), str(target), timeout=300)
        if not ok:
            return _explain(out)
        return f"Copied to {target}." if target.exists() else f"NOT confirmed: {target} was not created. {out[-200:]}"
    if a in ("push", "upload"):
        src = Path(dest or "").expanduser()
        if not src.exists():
            return "Give the local file to upload in dest."
        ok, out = _pmd("afc", "push", str(src), _safe_remote(path or "/Downloads/" + src.name), timeout=300)
        return f"Uploaded {src.name} to the iPhone." if ok else _explain(out)
    if a in ("delete", "rm"):
        if not path or path.strip("/") == "":
            return "Give the exact path to delete."
        ok, out = _pmd("afc", "rm", _safe_remote(path))
        return f"Deleted {path} from the iPhone." if ok else _explain(out)
    if a == "mkdir":
        ok, out = _pmd("afc", "mkdir", _safe_remote(path))
        return f"Created {path}." if ok else _explain(out)
    if a == "apps":
        ok, out = _pmd("apps", "list")
        return out[:4000] if ok else _explain(out)
    if a == "screenshot":
        target = _dest(dest, "iphone_screenshot.png")
        target = target / "iphone_screenshot.png" if target.is_dir() or not target.suffix else target
        ok, out = _pmd("developer", "dvt", "screenshot", str(target))
        if not ok:
            ok, out = _pmd("developer", "screenshot", str(target))
        if ok and target.exists():
            return f"Screenshot saved to {target}."
        return ("Screenshots need Developer Mode on the iPhone (Settings > Privacy & Security > "
                "Developer Mode). " + _explain(out))
    if a in ("launch", "open_app"):
        bundle = str(parameters.get("app", "") or "")
        if not bundle:
            return "Give the app's bundle id, e.g. com.apple.mobilesafari (see action=apps)."
        ok, out = _pmd("developer", "dvt", "launch", bundle)
        return f"Launched {bundle}." if ok else ("Launching needs Developer Mode on the iPhone. " + _explain(out))
    if a == "call":
        return _call(str(parameters.get("number", "") or ""))
    if a == "phone_link":
        return _phone_link()
    if a in ("whatsapp_call", "messenger_call", "instagram_call", "tap", "type", "swipe", "sms"):
        return ("Apple does not let a computer tap, type, send texts or start WhatsApp / Messenger / "
                "Instagram calls on an iPhone. For calls use action=call (Phone Link). An Android phone "
                "on USB can do all of this through the phone tool.")
    return ("Unknown action. Use: status | pair | wifi_on | info | battery | ls | photos | pull | push | "
            "delete | mkdir | apps | screenshot | launch | call | phone_link")


TOOL = {
    "name": "iphone",
    "description": (
        "Work with the user's iPhone, only after the owner has tapped Trust on the phone (action=pair "
        "triggers that request). Can show status/info/battery, list and copy photos and files (/DCIM), "
        "upload, delete, list apps, take screenshots and launch apps (Developer Mode), and place a normal "
        "phone call through Phone Link (action=call). Cannot tap/type on the phone or start "
        "WhatsApp/Messenger/Instagram calls — Apple blocks that; say so plainly. For an Android phone "
        "use the phone tool instead. Always report the tool's result exactly."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description":
                       "status | pair | wifi_on | info | battery | ls | photos | pull | push | delete | mkdir | apps | screenshot | launch | call | phone_link"},
            "path":   {"type": "STRING", "description": "Path on the iPhone, e.g. /DCIM/100APPLE/IMG_0001.JPG"},
            "dest":   {"type": "STRING", "description": "Local path (pull destination / push source)"},
            "app":    {"type": "STRING", "description": "App bundle id for launch"},
            "number": {"type": "STRING", "description": "Phone number for call"},
        },
        "required": ["action"],
    },
    "handler": iphone,
}

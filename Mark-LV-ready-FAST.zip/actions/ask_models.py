"""
actions/ask_models.py — a composite "brain": several AI services, each used for
what it is best at, behind one tool.

    task="problem_solving"  -> ChatGPT (OpenAI)      math, coding, step-by-step fixes
    task="research"         -> Gemini (Google)       web-grounded research with sources
    task="reasoning"        -> Grok (xAI)            hard logic / analysis
    task="open"             -> Venice AI             open-ended / less-filtered answers
    mode="composite"        -> asks several in parallel and merges them into one answer

Voice stays on Gemini Live (the only one of these that streams real-time speech);
this tool is what the assistant calls when a question needs a bigger brain.

Keys go in config/api_keys.json:
    "openai_api_key": "...",  "xai_api_key": "...",  "venice_api_key": "...",
    "gemini_api_key": "..."   (already there)
Optional model overrides (use action=models to list what your key can use):
    "openai_model", "xai_model", "venice_model"
Venice and the others apply their own usage policies to what they will answer.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import time

import requests

try:
    from config import get_config
except Exception:                                   # pragma: no cover
    def get_config() -> dict:
        return {}

_TIMEOUT = 60
_PROVIDERS = {
    # name: (base url, key field, model field, default model, label)
    "openai": ("https://api.openai.com/v1", "openai_api_key", "openai_model", "gpt-4o", "ChatGPT"),
    "xai":    ("https://api.x.ai/v1", "xai_api_key", "xai_model", "grok-4.3", "Grok"),
    "venice": ("https://api.venice.ai/api/v1", "venice_api_key", "venice_model", "venice-uncensored-1-2", "Venice AI"),
}
_ROUTE = {                          # task -> preferred provider, then fallbacks in order
    "problem_solving": ["openai", "xai", "gemini", "venice"],
    "research":        ["gemini", "openai", "xai", "venice"],
    "reasoning":       ["xai", "openai", "gemini", "venice"],
    "open":            ["venice", "openai", "xai", "gemini"],
}
_SYSTEM = ("You are one expert inside a voice assistant. Answer the question directly and "
           "accurately. Be concise: lead with the answer, then only the reasoning that matters. "
           "Plain prose, no markdown, because your answer will be spoken aloud.")


def _key(provider: str) -> str:
    cfg = get_config()
    if provider == "gemini":
        return str(cfg.get("gemini_api_key", "") or "")
    return str(cfg.get(_PROVIDERS[provider][1], "") or "")


def available() -> list[str]:
    return [p for p in ("openai", "gemini", "xai", "venice") if _key(p)]


def _chat(provider: str, question: str) -> str:
    base, kf, mf, default_model, label = _PROVIDERS[provider]
    cfg = get_config()
    model = str(cfg.get(mf, "") or default_model)
    r = requests.post(
        f"{base}/chat/completions",
        headers={"Authorization": f"Bearer {_key(provider)}", "Content-Type": "application/json"},
        json={"model": model,
              "messages": [{"role": "system", "content": _SYSTEM},
                           {"role": "user", "content": question}]},
        timeout=_TIMEOUT)
    if r.status_code != 200:
        raise RuntimeError(f"{label} returned {r.status_code}: {r.text[:200]}")
    return (r.json()["choices"][0]["message"]["content"] or "").strip()


def _gemini(question: str) -> str:
    from core import gemini
    try:
        from google.genai import types
        cfg = types.GenerateContentConfig(
            system_instruction=_SYSTEM,
            tools=[types.Tool(google_search=types.GoogleSearch())])
        out = gemini.text(question, tier=gemini.SEARCH, config=cfg, timeout_ms=45000)
        if out:
            return out
    except Exception:
        pass
    out = gemini.text(question, tier=gemini.SMART, timeout_ms=45000)
    if not out:
        raise RuntimeError("Gemini did not answer")
    return out


def _ask(provider: str, question: str) -> tuple[str, str]:
    """-> (label, answer). Raises on failure."""
    if provider == "gemini":
        return "Gemini", _gemini(question)
    return _PROVIDERS[provider][4], _chat(provider, question)


def _single(task: str, question: str, forced: str = "") -> str:
    order = [forced] if forced else _ROUTE.get(task, _ROUTE["problem_solving"])
    errors = []
    for p in order:
        if p not in ("gemini", *_PROVIDERS) or not _key(p):
            continue
        try:
            label, ans = _ask(p, question)
            if ans:
                return f"[{label}] {ans}"
        except Exception as e:
            errors.append(f"{p}: {e}")
            if forced:
                break
    if forced and not _key(forced):
        return f"No API key for '{forced}'. Add it to config/api_keys.json."
    return "No model could answer. " + ("; ".join(errors) if errors else
                                         "Add at least one API key to config/api_keys.json.")


def _composite(question: str, task: str) -> str:
    have = available()
    if not have:
        return "No API keys are set. Add them to config/api_keys.json."
    if len(have) == 1:
        return _single(task, question, have[0])
    with cf.ThreadPoolExecutor(len(have)) as ex:
        futs = {p: ex.submit(_ask, p, question) for p in have}
        answers = {}
        for p, f in futs.items():
            try:
                label, ans = f.result(timeout=_TIMEOUT + 10)
                if ans:
                    answers[label] = ans
            except Exception:
                pass
    if not answers:
        return "None of the models answered."
    if len(answers) == 1:
        (label, ans), = answers.items()
        return f"[{label}] {ans}"
    # merge with the best available reasoner
    judge = next((p for p in ("openai", "xai", "gemini", "venice") if p in have), have[0])
    packed = "\n\n".join(f"--- {k} ---\n{v}" for k, v in answers.items())
    prompt = (f"Question: {question}\n\nSeveral experts answered:\n{packed}\n\n"
              f"Write the single best final answer. Keep what they agree on, resolve or "
              f"flag any disagreement briefly, and drop anything wrong or padded.")
    try:
        _, final = _ask(judge, prompt)
        return f"[Composite of {', '.join(answers)}] {final}"
    except Exception:
        k, v = next(iter(answers.items()))
        return f"[{k}] {v}"


def _models(provider: str) -> str:
    if provider not in _PROVIDERS or not _key(provider):
        return "Name a provider with a key set: openai | xai | venice."
    base = _PROVIDERS[provider][0]
    r = requests.get(f"{base}/models", headers={"Authorization": f"Bearer {_key(provider)}"},
                     timeout=20)
    if r.status_code != 200:
        return f"Could not list models ({r.status_code})."
    ids = sorted(m.get("id", "") for m in r.json().get("data", []))
    return "\n".join(ids[:80])


def ask_models(parameters: dict, player=None) -> str:
    q = str(parameters.get("question", "") or "").strip()
    task = str(parameters.get("task", "problem_solving") or "problem_solving").lower().strip()
    mode = str(parameters.get("mode", "") or "").lower().strip()
    prov = str(parameters.get("provider", "") or "").lower().strip()
    if mode == "status" or task == "status":
        have = available()
        return ("Keys set for: " + ", ".join(have)) if have else "No API keys set yet."
    if mode == "models":
        return _models(prov)
    if not q:
        return "What should I ask?"
    if player:
        try:
            player.write_log(f"[ask_models] {task}{' (composite)' if mode == 'composite' else ''}")
        except Exception:
            pass
    t0 = time.time()
    out = _composite(q, task) if mode == "composite" else _single(task, q, prov)
    return f"{out}\n(took {time.time() - t0:.1f}s)"


TOOL = {
    "name": "ask_models",
    "description": (
        "Consult bigger AI models for hard questions, then speak the answer in your own words, "
        "briefly. task=problem_solving -> ChatGPT (maths, code, step-by-step fixes); "
        "task=research -> Gemini with web search (facts, current events, comparisons); "
        "task=reasoning -> Grok (logic, analysis, planning); task=open -> Venice AI (open-ended "
        "questions). mode=composite asks several at once and merges the best answer — use it for "
        "important or contested questions. mode=status shows which keys are set. If it says a "
        "key is missing, tell the user which one to add."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "question": {"type": "STRING", "description": "The full question, with all needed context"},
            "task":     {"type": "STRING", "description": "problem_solving | research | reasoning | open"},
            "mode":     {"type": "STRING", "description": "composite | status | models (optional)"},
            "provider": {"type": "STRING", "description": "Force one: openai | gemini | xai | venice (optional)"},
        },
        "required": ["question"],
    },
    "handler": ask_models,
}

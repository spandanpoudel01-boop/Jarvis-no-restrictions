"""actions/persona_tool.py — lets the model read/update its adaptation profile live."""
from core.persona import persona

TOOL = {
    "name": "persona",
    "description": (
        "Reads or updates how you adapt to the user. action=status returns their current mood and "
        "the style to use; action=remember stores a lasting note about how they like to be treated "
        "(e.g. 'prefers short answers in the morning'). Check status when the user sounds stressed, "
        "frustrated, tired or upset, and adjust your tone to it."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "status | remember"},
            "note":   {"type": "STRING", "description": "The note to remember (for action=remember)"},
        },
        "required": ["action"],
    },
    "handler": persona,
}

"""
actions/phone.py — use a USB-connected phone as an extension of this computer.

Android (full control, via ADB)
    One-time setup on the phone: Settings -> About -> tap Build number 7 times ->
    Developer options -> USB debugging ON, then accept the "Allow USB debugging?"
    prompt when you plug in. Needs `adb` on the PATH (platform-tools); `scrcpy`
    is optional but gives a live mirrored, mouse/keyboard-controllable screen.

iPhone (limited — Apple does not allow remote control over USB)
    With libimobiledevice installed: device info and screenshots only.

Everything here acts only on the device you have plugged in and authorised.
"""
from __future__ import annotations

import re
import shlex
import sys
import shutil
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path


_NOWIN = 0x08000000 if sys.platform == "win32" else 0   # no console window flashes


def _adb(*args: str, timeout: int = 60, binary: bool = False):
    if not shutil.which("adb"):
        return False, "adb is not installed. Get Android platform-tools and add it to PATH."
    try:
        r = subprocess.run(["adb", *args], capture_output=True, timeout=timeout,
                           creationflags=_NOWIN)
        out = r.stdout if binary else (r.stdout + r.stderr).decode(errors="replace").strip()
        return r.returncode == 0, out
    except subprocess.TimeoutExpired:
        return False, "Timed out."
    except Exception as e:
        return False, str(e)


def _sh(cmd: str, timeout: int = 60) -> tuple[bool, str]:
    return _adb("shell", cmd, timeout=timeout)


def devices_list() -> list[str]:
    ok, out = _adb("devices")
    return [l.split("\t")[0] for l in out.splitlines() if l.endswith("\tdevice")] if ok else []


def _status() -> str:
    ds = devices_list()
    if ds:
        _, model = _sh("getprop ro.product.model")
        _, ver = _sh("getprop ro.build.version.release")
        _, bat = _sh("dumpsys battery | grep level")
        return f"Android phone connected: {model} (Android {ver}), {bat.strip()}."
    ok, out = _adb("devices")
    if "unauthorized" in out:
        return "Phone found but not authorised: unlock it and tap Allow on the USB debugging prompt."
    if shutil.which("idevice_id"):
        r = subprocess.run(["idevice_id", "-l"], capture_output=True, text=True)
        if r.stdout.strip():
            return f"iPhone connected ({r.stdout.split()[0]}). Only info and screenshots are possible over USB."
    return "No phone detected. Plug it in by USB and enable USB debugging."


def _ui_dump() -> ET.Element | None:
    ok, out = _sh("uiautomator dump /sdcard/_ui.xml >/dev/null 2>&1 && cat /sdcard/_ui.xml")
    if not ok or "<hierarchy" not in out:
        return None
    try:
        return ET.fromstring(out[out.index("<hierarchy"):])
    except ET.ParseError:
        return None


def tap_text(label: str) -> str:
    """Tap the on-screen element whose text or description contains `label`."""
    root = _ui_dump()
    if root is None:
        return "Could not read the phone screen (is it unlocked?)."
    want = label.lower()
    for n in root.iter("node"):
        if want in (n.get("text", "") + " " + n.get("content-desc", "")).lower():
            m = re.findall(r"\d+", n.get("bounds", ""))
            if len(m) == 4:
                x = (int(m[0]) + int(m[2])) // 2
                y = (int(m[1]) + int(m[3])) // 2
                _sh(f"input tap {x} {y}")
                return f"Tapped '{label}'."
    return f"'{label}' is not visible on the phone screen."


def phone(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "status")).lower().strip()
    if player:
        player.write_log(f"[phone] {a}")
    v = str(parameters.get("value", "") or "")
    path = str(parameters.get("path", "") or "")
    dest = str(parameters.get("destination", "") or "")

    if a == "status":
        return _status()
    if a == "pair":      # wireless debugging: value = "ip:port" shown on the phone, path = 6-digit code
        return _adb("pair", v, path, timeout=30)[1]
    if a == "connect":   # wireless debugging: value = "ip:port"
        return _adb("connect", v, timeout=20)[1]
    if not devices_list():
        if a == "screenshot" and shutil.which("idevicescreenshot"):
            out = Path(dest or Path.home() / "iphone_screenshot.png")
            subprocess.run(["idevicescreenshot", str(out)], timeout=30)
            return f"iPhone screenshot saved to {out}."
        return _status()

    if a == "mirror":   # live screen with mouse/keyboard control
        if not shutil.which("scrcpy"):
            return "scrcpy is not installed (https://github.com/Genymobile/scrcpy). It gives the live mirrored, controllable screen."
        subprocess.Popen(["scrcpy", "--stay-awake"] + shlex.split(v))
        return "Phone screen opened on your computer — click and type there to control it."
    if a == "screenshot":
        ok, data = _adb("exec-out", "screencap", "-p", binary=True)
        if not ok:
            return f"Screenshot failed: {data}"
        out = Path(dest).expanduser() if dest else Path(tempfile.gettempdir()) / f"phone_{int(time.time())}.png"
        out.write_bytes(data)
        return f"Phone screenshot saved to {out}."
    if a == "record":
        secs = int(float(v or 10))
        _sh(f"screenrecord --time-limit {secs} /sdcard/_rec.mp4", timeout=secs + 15)
        out = Path(dest).expanduser() if dest else Path.home() / "phone_recording.mp4"
        ok, o = _adb("pull", "/sdcard/_rec.mp4", str(out))
        return f"Recording saved to {out}." if ok else o
    if a == "tap":
        x, y = (re.findall(r"\d+", v) + ["0", "0"])[:2]
        return _sh(f"input tap {x} {y}")[1] or "Tapped."
    if a == "tap_text":
        return tap_text(v)
    if a == "swipe":     # value: "x1 y1 x2 y2 [ms]"
        n = re.findall(r"\d+", v)
        if len(n) < 4:
            return "Give swipe as 'x1 y1 x2 y2 [duration_ms]'."
        return _sh("input swipe " + " ".join(n[:5])) [1] or "Swiped."
    if a == "type":
        return _sh("input text " + shlex.quote(v.replace(" ", "%s")))[1] or "Typed."
    if a == "key":       # HOME BACK POWER VOLUME_UP ... or a number
        k = v.upper() if v.isdigit() else "KEYCODE_" + v.upper().replace("KEYCODE_", "")
        return _sh(f"input keyevent {k}")[1] or f"Pressed {v}."
    if a == "wake":
        _sh("input keyevent KEYCODE_WAKEUP")
        _sh("input swipe 540 1800 540 600 200")
        return "Phone woken. If it has a PIN, tell me to type it."
    if a == "open_app":
        pkg = v
        ok, o = _sh(f"monkey -p {shlex.quote(pkg)} -c android.intent.category.LAUNCHER 1")
        if ok and "No activities found" not in o:
            return f"Opened {pkg}."
        # not a package name: try matching an installed package
        ok, lst = _sh("pm list packages")
        hits = [l.split(":")[1] for l in lst.splitlines() if v.lower() in l.lower()]
        if hits:
            _sh(f"monkey -p {hits[0]} -c android.intent.category.LAUNCHER 1")
            return f"Opened {hits[0]}."
        return f"No app matching '{v}' on the phone."
    if a == "open_url":
        return _sh(f"am start -a android.intent.action.VIEW -d {shlex.quote(v)}")[1]
    if a == "install":
        ok, o = _adb("install", "-r", str(Path(path).expanduser()), timeout=300)
        return o
    if a == "uninstall":
        return _adb("uninstall", v)[1]
    if a == "list_apps":
        ok, o = _sh("pm list packages -3")
        return o.replace("package:", "")
    if a == "ls":
        return _sh(f"ls -la {shlex.quote(path or '/sdcard/')}")[1]
    if a == "pull":      # phone -> computer
        out = Path(dest or Path.home() / "Downloads").expanduser()
        out.mkdir(parents=True, exist_ok=True)
        return _adb("pull", path, str(out), timeout=900)[1]
    if a == "push":      # computer -> phone
        return _adb("push", str(Path(path).expanduser()), dest or "/sdcard/Download/", timeout=900)[1]
    if a == "delete":
        return _sh(f"rm -rf {shlex.quote(path)}")[1] or f"Deleted {path} on the phone."
    if a == "notifications":
        ok, o = _sh("dumpsys notification --noredact | grep -E 'pkg=|android.title|android.text' | head -60")
        return o or "No notifications."
    if a == "battery":
        return _sh("dumpsys battery")[1]
    if a == "volume":
        return _sh(f"media volume --set {int(v or 8)}")[1] or "Volume set."
    if a == "brightness":
        return _sh(f"settings put system screen_brightness {int(v or 128)}")[1] or "Brightness set."
    if a == "wifi":
        return _sh(f"svc wifi {'enable' if v.lower() != 'off' else 'disable'}")[1] or f"WiFi {v or 'on'}."
    if a == "bluetooth":
        return _sh(f"svc bluetooth {'enable' if v.lower() != 'off' else 'disable'}")[1] or f"Bluetooth {v or 'on'}."
    if a == "lock":
        return _sh("input keyevent KEYCODE_SLEEP")[1] or "Locked."
    if a == "reboot":
        return _adb("reboot")[1] or "Rebooting the phone."
    if a == "shell":
        return _sh(v, timeout=120)[1] or "(no output)"
    return ("Unknown action. Use: status | mirror | screenshot | record | tap | tap_text | swipe | type | key | "
            "wake | lock | open_app | open_url | install | uninstall | list_apps | ls | pull | push | delete | "
            "notifications | battery | volume | brightness | wifi | bluetooth | reboot | shell")


TOOL = {
    "name": "phone",
    "description": (
        "Uses the USB-connected phone like an extra device of this computer: see and control its "
        "screen (mirror, screenshot, tap, swipe, type, keys, tap a labelled button), open apps and "
        "links, install/uninstall apps, browse/copy/delete files in both directions, read "
        "notifications, battery, volume, WiFi/Bluetooth, lock/wake/reboot, and run any adb shell "
        "command. Check action=status first when the user mentions their phone. To use it without a cable: on the phone turn on Wireless debugging, then action=pair (value ip:port, path code) and action=connect (value ip:port) — the phone shows its own approval prompt."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description":
                       "status | pair | connect | mirror | screenshot | record | tap | tap_text | swipe | type | key | wake | lock | open_app | open_url | install | uninstall | list_apps | ls | pull | push | delete | notifications | battery | volume | brightness | wifi | bluetooth | reboot | shell"},
            "value":       {"type": "STRING", "description": "Argument: text, 'x y', 'x1 y1 x2 y2', app name/package, URL, key name, shell command, on/off, level"},
            "path":        {"type": "STRING", "description": "File path (on the phone for ls/pull/delete; on the computer for push/install)"},
            "destination": {"type": "STRING", "description": "Destination path (computer folder for pull/screenshot; phone folder for push)"},
        },
        "required": ["action"],
    },
    "handler": phone,
}


def start_watch(log) -> None:
    """Background thread: announce in the log when a phone is plugged in / removed."""
    import threading

    def loop():
        seen: set[str] = set()
        while True:
            try:
                now = set(devices_list())
                for d in now - seen:
                    log(f"SYS: Phone connected over USB ({d}). I can control it — just ask.")
                for d in seen - now:
                    log(f"SYS: Phone disconnected ({d}).")
                seen = now
            except Exception:
                pass
            time.sleep(10)

    if shutil.which("adb"):
        threading.Thread(target=loop, daemon=True, name="phone-watch").start()

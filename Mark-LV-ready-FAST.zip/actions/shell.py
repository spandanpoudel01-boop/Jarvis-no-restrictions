"""
actions/shell.py — run a command on this computer and return exactly what it printed.

Windows uses PowerShell (cmd for shell=cmd), other systems use the default shell.
In unrestricted mode (config unrestricted_mode, on by default) it just runs. With
unrestricted mode off, every command asks for confirmation first.
"""
from __future__ import annotations

import subprocess
import sys

_NOWIN = 0x08000000 if sys.platform == "win32" else 0


def run_command(parameters: dict, player=None) -> str:
    cmd = str(parameters.get("command", "") or "").strip()
    if not cmd:
        return "No command given."
    which = str(parameters.get("shell", "") or "").lower()
    try:
        timeout = max(1, min(int(parameters.get("timeout", 60) or 60), 600))
    except Exception:
        timeout = 60
    cwd = str(parameters.get("cwd", "") or "") or None
    try:
        from config import unrestricted
        free = unrestricted()
    except Exception:
        free = True
    if player:
        try:
            player.write_log(f"[shell] {cmd[:80]}")
        except Exception:
            pass
    if not free:
        from core import confirm
        return confirm.request("shell", "Run a command", cmd[:300],
                               lambda: _exec(cmd, which, timeout, cwd))
    return _exec(cmd, which, timeout, cwd)


def _exec(cmd: str, which: str, timeout: int, cwd) -> str:
    if sys.platform == "win32" and which != "cmd":
        args = ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd]
        shell = False
    else:
        args, shell = cmd, True
    try:
        r = subprocess.run(args, shell=shell, capture_output=True, text=True, timeout=timeout,
                           cwd=cwd, creationflags=_NOWIN)
    except subprocess.TimeoutExpired:
        return f"Timed out after {timeout}s (the command may still be running)."
    except Exception as e:
        return f"NOT run: {e}"
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    return f"exit code {r.returncode}\n{out[-4000:]}" if out else f"exit code {r.returncode} (no output)"


TOOL = {
    "name": "run_command",
    "description": (
        "Run a command on this computer (PowerShell on Windows) and get its exact output and exit "
        "code: install software, check or change settings, run scripts, anything the user asks. "
        "Report the exit code and output faithfully; a non-zero exit code means it failed."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "command": {"type": "STRING", "description": "The command line to run"},
            "shell":   {"type": "STRING", "description": "powershell (default on Windows) | cmd"},
            "cwd":     {"type": "STRING", "description": "Working folder (optional)"},
            "timeout": {"type": "INTEGER", "description": "Seconds before giving up (default 60, max 600)"},
        },
        "required": ["command"],
    },
    "handler": run_command,
}

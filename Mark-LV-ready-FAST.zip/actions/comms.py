"""
actions/comms.py — phone calls, SMS, email and reservations.

What each one really uses (set these in config/api_keys.json):

  phone_call / sms
      Preferred: an Android phone on USB with USB debugging, driven by ADB
      (nothing to configure beyond `adb` being installed). The call/SMS goes out
      over the phone's own SIM.
      Alternative for SMS: Twilio — "twilio_sid", "twilio_token", "twilio_from".
      Fallback for calls: the tel: handler (Windows Phone Link, macOS
      FaceTime/iPhone Continuity, KDE Connect on Linux).

  email
      SMTP — "smtp_host", "smtp_port" (587 default), "smtp_user",
      "smtp_password" (a Gmail *app password*, not your login), optional
      "smtp_from".

  reservation
      There is no universal booking API. If a phone number is given it calls the
      venue; otherwise it opens a prefilled OpenTable / Google search for the
      requested place, party size, date and time so you finish it in one click.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import smtplib
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import webbrowser
from email.message import EmailMessage
from pathlib import Path

_PHONE_RE = re.compile(r"^\+?[0-9][0-9 ()\-]{4,18}$")


def _cfg() -> dict:
    try:
        from config import get_config
        return get_config()
    except Exception:
        return {}


def _clean_number(n: str) -> str | None:
    n = (n or "").strip()
    if not _PHONE_RE.match(n):
        return None
    return re.sub(r"[ ()\-]", "", n)


def _adb(*args: str, timeout: int = 20) -> tuple[bool, str]:
    if not shutil.which("adb"):
        return False, "adb is not installed"
    try:
        r = subprocess.run(["adb", *args], capture_output=True, text=True, timeout=timeout,
                           creationflags=0x08000000 if sys.platform == "win32" else 0)
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        return r.returncode == 0 and "no devices" not in out.lower(), out
    except Exception as e:
        return False, str(e)


def _phone_connected() -> bool:
    ok, out = _adb("devices")
    return ok and any(l.endswith("\tdevice") for l in out.splitlines())


def _open_uri(uri: str) -> None:
    if sys.platform == "win32":
        os.startfile(uri)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", uri])
    else:
        subprocess.Popen(["xdg-open", uri])


# ── calls ────────────────────────────────────────────────────────────────────
def _call(number: str, end: bool = False) -> str:
    if end:
        if _phone_connected():
            _adb("shell", "input", "keyevent", "KEYCODE_ENDCALL")
            return "Call ended."
        return "No phone connected over ADB to end the call."
    num = _clean_number(number)
    if not num:
        return "That does not look like a phone number."
    if _phone_connected():
        ok, out = _adb("shell", "am", "start", "-a", "android.intent.action.CALL",
                       "-d", f"tel:{num}")
        return f"Calling {num} from your phone." if ok else f"Phone refused the call: {out}"
    try:
        _open_uri(f"tel:{num}")
        return f"Opened the dialer for {num} (no ADB phone found; your tel: handler takes it from here)."
    except Exception as e:
        return f"Could not place the call: {e}. Connect an Android phone with USB debugging."


# ── SMS ──────────────────────────────────────────────────────────────────────
def _sms(number: str, text: str) -> str:
    num = _clean_number(number)
    if not num or not text.strip():
        return "Need a valid phone number and message text."
    c = _cfg()
    if c.get("twilio_sid") and c.get("twilio_token") and c.get("twilio_from"):
        try:
            url = f"https://api.twilio.com/2010-04-01/Accounts/{c['twilio_sid']}/Messages.json"
            body = urllib.parse.urlencode({"To": num, "From": c["twilio_from"], "Body": text}).encode()
            req = urllib.request.Request(url, data=body)
            import base64
            tok = base64.b64encode(f"{c['twilio_sid']}:{c['twilio_token']}".encode()).decode()
            req.add_header("Authorization", f"Basic {tok}")
            with urllib.request.urlopen(req, timeout=20) as r:
                return f"SMS sent to {num} via Twilio." if r.status < 300 else f"Twilio error {r.status}"
        except Exception as e:
            return f"SMS NOT sent (Twilio): {e}"
    if _phone_connected():
        ok, out = _adb("shell", "am", "start", "-a", "android.intent.action.SENDTO",
                       "-d", f"sms:{num}", "--es", "sms_body", shlex.quote(text),
                       "--ez", "exit_on_sent", "true")
        if not ok:
            return f"SMS NOT sent: {out}"
        time.sleep(1.5)
        _adb("shell", "input", "keyevent", "KEYCODE_ENTER")   # Send on most Messages apps
        return (f"SMS composed to {num} on your phone and Send pressed. "
                f"Not verified — check the phone if it is important.")
    return "SMS NOT sent: connect an Android phone (ADB) or add twilio_* keys to config."


# ── email ────────────────────────────────────────────────────────────────────
def _email(to: str, subject: str, body: str, attachment: str = "") -> str:
    c = _cfg()
    host, user, pw = c.get("smtp_host"), c.get("smtp_user"), c.get("smtp_password")
    if not (host and user and pw):
        return ("Email NOT sent: add smtp_host, smtp_user and smtp_password "
                "(Gmail: smtp.gmail.com + an app password) to config/api_keys.json.")
    if not re.match(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$", to or ""):
        return f"Email NOT sent: '{to}' is not a valid address."
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = c.get("smtp_from") or user, to, subject or "(no subject)"
    msg.set_content(body or "")
    if attachment:
        p = Path(attachment).expanduser()
        if p.is_file():
            msg.add_attachment(p.read_bytes(), maintype="application", subtype="octet-stream",
                               filename=p.name)
        else:
            return f"Email NOT sent: attachment not found: {attachment}"
    try:
        port = int(c.get("smtp_port", 587))
        if port == 465:
            s = smtplib.SMTP_SSL(host, port, timeout=30)
        else:
            s = smtplib.SMTP(host, port, timeout=30)
            s.starttls()
        with s:
            s.login(user, pw)
            s.send_message(msg)
        return f"Email sent to {to}."
    except Exception as e:
        return f"Email NOT sent: {e}"



# ── calls through messaging apps (WhatsApp, Telegram, Viber) ────────────────
_APPS = {
    # app: (android package, contacts mimetype for a voice call or None, deep link template)
    "whatsapp": ("com.whatsapp", "vnd.android.cursor.item/vnd.com.whatsapp.voip.call",
                 "https://wa.me/{num}"),
    "telegram": ("org.telegram.messenger", "vnd.android.cursor.item/vnd.org.telegram.messenger.android.call",
                 "tg://resolve?phone={num}"),
    "viber":    ("com.viber.voip", None, "viber://chat?number={num}"),
}


def _contact_data_id(mime: str, name: str) -> str | None:
    safe = re.sub(r"[^\w .\-]", "", name)
    where = f"mimetype='{mime}' AND display_name LIKE '%{safe}%'"
    ok, out = _adb("shell", "content", "query", "--uri", "content://com.android.contacts/data",
                   "--projection", "_id:display_name", "--where", shlex.quote(where))
    m = re.search(r"_id=(\d+)", out) if ok else None
    return m.group(1) if m else None


def _app_call(app: str, target: str, video: bool = False) -> str:
    app = (app or "whatsapp").lower().strip()
    if app not in _APPS:
        return f"Calling through '{app}' is not set up. Supported: {', '.join(_APPS)}."
    pkg, mime, link = _APPS[app]
    is_num = bool(_clean_number(target))
    if _phone_connected():
        # 1) By contact name: jump straight into the app's own call entry.
        if mime and not is_num:
            cid = _contact_data_id(mime, target)
            if cid:
                ok, out = _adb("shell", "am", "start", "-a", "android.intent.action.VIEW",
                               "-d", f"content://com.android.contacts/data/{cid}", "-t", mime, "-p", pkg)
                return (f"Calling {target} on {app.title()}." if ok
                        else f"{app.title()} call NOT started: {out}")
            return f"No {app.title()} contact named '{target}' on the phone."
        if not is_num:
            return f"Give me a phone number for {app.title()} (name lookup is not available for it)."
        num = _clean_number(target).lstrip("+")
        ok, out = _adb("shell", "am", "start", "-a", "android.intent.action.VIEW",
                       "-d", shlex.quote(link.format(num=num)), "-p", pkg)
        if not ok:
            return f"{app.title()} call NOT started: {out}"
        time.sleep(3)
        from actions.phone import tap_text
        labels = ["Video call", "Video"] if video else ["Voice call", "Call", "Free call"]
        for lab in labels:
            r = tap_text(lab)
            if r.startswith("Tapped"):
                return f"Calling {target} on {app.title()}."
        return f"Opened the {app.title()} chat with {target}, but could not find the call button — tap it yourself."
    # No phone attached: use the desktop app and find the button by sight.
    try:
        _open_uri(link.format(num=_clean_number(target).lstrip("+")) if is_num else f"{app}://")
        time.sleep(4)
        from actions.computer_control import computer_control
        desc = "video call button" if video else "voice call (phone) button"
        res = computer_control({"action": "screen_click", "description": desc})
        return f"Tried to start a {app.title()} call with {target} on the desktop app: {res}"
    except Exception as e:
        return f"{app.title()} call NOT started: {e}"


def _sos() -> str:
    c = _cfg()
    who = c.get("emergency_contact", "")
    if not who:
        return "No emergency_contact is set in config/api_keys.json (a phone number)."
    name = c.get("user_name") or "your family member"
    msg = f"{name} pressed the help button and needs you. Please call back now."
    r1 = _sms(who, msg)
    r2 = _call(who)
    return f"Emergency: {r1} {r2}"


# ── reservations ─────────────────────────────────────────────────────────────
def _reserve(place: str, party: int, date: str, time_s: str, phone: str, notes: str) -> str:
    if not place:
        return "Which restaurant or venue?"
    if phone:
        res = _call(phone)
        return (f"{res} Ask for a table for {party or 2} on {date or 'the requested date'} "
                f"at {time_s or 'the requested time'} at {place}. {notes}").strip()
    q = urllib.parse.quote(f"{place} reservation")
    url = f"https://www.opentable.com/s?term={urllib.parse.quote(place)}&covers={party or 2}"
    if date and time_s:
        url += f"&dateTime={urllib.parse.quote(date)}T{urllib.parse.quote(time_s)}"
    try:
        webbrowser.open(url)
        return (f"Opened OpenTable for {place}, party of {party or 2}. "
                f"Pick the slot and confirm — booking needs your account. "
                f"Fallback search: https://www.google.com/search?q={q}")
    except Exception as e:
        return f"Could not open a browser: {e}"


def comms(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "")).lower().strip()
    if player:
        player.write_log(f"[comms] {a}")
    if a in ("call", "phone_call"):
        return _call(str(parameters.get("number", "")))
    if a in ("app_call", "whatsapp_call", "telegram_call", "video_call"):
        app = str(parameters.get("app", "")) or a.split("_")[0]
        if app in ("app", "video"):
            app = "whatsapp"
        return _app_call(app, str(parameters.get("number", "")) or str(parameters.get("name", "")),
                         video=(a == "video_call" or str(parameters.get("video", "")).lower() == "true"))
    if a in ("sos", "emergency", "help"):
        return _sos()
    if a in ("end_call", "hangup"):
        return _call("", end=True)
    if a == "sms":
        return _sms(str(parameters.get("number", "")), str(parameters.get("text", "")))
    if a == "email":
        return _email(str(parameters.get("to", "")), str(parameters.get("subject", "")),
                      str(parameters.get("text", "")), str(parameters.get("attachment", "")))
    if a == "reservation":
        try:
            party = int(parameters.get("party_size", 2) or 2)
        except (TypeError, ValueError):
            party = 2
        return _reserve(str(parameters.get("place", "")), party, str(parameters.get("date", "")),
                        str(parameters.get("time", "")), str(parameters.get("number", "")),
                        str(parameters.get("text", "")))
    return "Unknown action. Use: call | app_call | video_call | end_call | sms | email | reservation | sos"


TOOL = {
    "name": "comms",
    "description": (
        "Phone calls, calls through WhatsApp/Telegram/Viber (action=app_call, by contact name or number), SMS, email, reservations, and sos (texts and calls the emergency contact). call/end_call/sms go through a USB-connected "
        "Android phone (ADB) or Twilio; email goes through SMTP; reservation calls the venue if a "
        "number is given, otherwise opens a prefilled booking page. Write text in the user's own "
        "language. If the result says NOT sent, say so plainly with the reason — never claim success."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":     {"type": "STRING", "description": "call | app_call | video_call | end_call | sms | email | reservation | sos"},
            "app":        {"type": "STRING", "description": "For app_call: whatsapp | telegram | viber"},
            "name":       {"type": "STRING", "description": "Contact name (for app_call by name)"},
            "number":     {"type": "STRING", "description": "Phone number with country code"},
            "to":         {"type": "STRING", "description": "Email address"},
            "subject":    {"type": "STRING", "description": "Email subject"},
            "text":       {"type": "STRING", "description": "SMS/email body, or reservation notes"},
            "attachment": {"type": "STRING", "description": "File path to attach to an email"},
            "place":      {"type": "STRING", "description": "Restaurant/venue name for reservation"},
            "party_size": {"type": "INTEGER", "description": "Number of people"},
            "date":       {"type": "STRING", "description": "YYYY-MM-DD"},
            "time":       {"type": "STRING", "description": "HH:MM 24h"},
        },
        "required": ["action"],
    },
    "handler": comms,
}

"""
actions/network.py — see what is on the local network and nearby WiFi, join
WiFi networks, and link to other devices with THEIR owner's permission.

  scan            list devices on your own (private) network
  wifi_list       nearby WiFi networks
  wifi_connect    join a WiFi network (ssid, optional password)
  link_request    send a connection request to a device running link_agent.py;
                  its owner must press Yes. Nothing is controlled before that.
  link_send       once accepted: message | open_url | lock | info | screenshot
                  (and type_text | key | click if that device allowed input)
  link_list / link_forget

Bluetooth and Android phones have their own consent step built in (the pairing
prompt on the other device, USB/wireless-debugging approval); use the `devices`
and `phone` tools for them.
"""
from __future__ import annotations

import base64
import concurrent.futures as cf
import hashlib
import hmac
import ipaddress
import json
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

LINK_PORT = 47474
_NOWIN = 0x08000000 if sys.platform == "win32" else 0
_STORE = Path(__file__).resolve().parent.parent / "config" / "links.json"
_PORTS = (445, 139, 135, 80, 443, 22, 5555, 8009, 8080, 62078, 7000, LINK_PORT)


def _run(cmd, timeout=30) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           creationflags=_NOWIN)
        return (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return f"ERR {e}"


# ── LAN scan ─────────────────────────────────────────────────────────────────
def _local_net():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    mask = "255.255.255.0"
    try:
        import psutil
        for addrs in psutil.net_if_addrs().values():
            for a in addrs:
                if a.family == socket.AF_INET and a.address == ip and a.netmask:
                    mask = a.netmask
    except Exception:
        pass
    net = ipaddress.ip_network(f"{ip}/{mask}", strict=False)
    if net.prefixlen < 22:                      # never sweep more than ~1000 hosts
        net = ipaddress.ip_network(f"{ip}/22", strict=False)
    return ip, net


def _alive(ip: str) -> bool:
    for port in _PORTS:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.25)
        try:
            s.connect((ip, port))
            return True
        except ConnectionRefusedError:
            return True                          # a refusal means a host answered
        except Exception:
            pass
        finally:
            s.close()
    return False


def _arp() -> dict[str, str]:
    out = _run(["arp", "-a"])
    table = {}
    for m in re.finditer(r"(\d+\.\d+\.\d+\.\d+)\D+?([0-9a-fA-F]{2}(?:[:-][0-9a-fA-F]{2}){5})", out):
        table[m.group(1)] = m.group(2).lower().replace("-", ":")
    return table


def _name(ip: str) -> str:
    try:
        return socket.gethostbyaddr(ip)[0]
    except Exception:
        return ""


def _link_ready(ip: str) -> bool:
    try:
        with socket.create_connection((ip, LINK_PORT), timeout=0.4) as c:
            c.sendall(b'{"type":"hello"}\n')
            return b"mark-lv-link" in c.recv(512)
    except Exception:
        return False


def _scan() -> str:
    me, net = _local_net()
    if not (net.is_private):
        return "This is not a private network, so I will not scan it."
    hosts = [str(h) for h in net.hosts() if str(h) != me]
    with cf.ThreadPoolExecutor(96) as ex:
        up = {ip for ip, ok in zip(hosts, ex.map(_alive, hosts)) if ok}
    arp = _arp()
    up |= {ip for ip in arp if ipaddress.ip_address(ip) in net and ip != me
           and not ip.endswith(".255") and not ip.startswith("224.")}
    ips = sorted(up, key=lambda x: ipaddress.ip_address(x))
    with cf.ThreadPoolExecutor(32) as ex:
        names = dict(zip(ips, ex.map(_name, ips)))
        ready = dict(zip(ips, ex.map(_link_ready, ips)))
    rows = [f"{ip:<16} {arp.get(ip, '?'):<18} {names[ip] or '-':<32}"
            + ("  [Mark-LV Link ready]" if ready[ip] else "") for ip in ips]
    return (f"Network {net} (this laptop: {me}) — {len(ips)} device(s):\n"
            + "\n".join(rows) if rows else f"No other devices answered on {net}.")


# ── WiFi ─────────────────────────────────────────────────────────────────────
def _wifi_list() -> str:
    if sys.platform == "win32":
        out = _run(["netsh", "wlan", "show", "networks", "mode=bssid"], 20)
        nets = re.findall(r"SSID \d+ : (.*)", out)
        sig = re.findall(r"Signal\s*:\s*(\d+%)", out)
        return "\n".join(f"{n.strip() or '(hidden)'}  {sig[i] if i < len(sig) else ''}"
                         for i, n in enumerate(nets)) or out[:400]
    if sys.platform == "darwin":
        air = "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
        return _run([air, "-s"], 20)
    return _run(["nmcli", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi"], 20)


def _esc(x: str) -> str:
    return (x.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))


def _wifi_connect(ssid: str, password: str) -> str:
    if not ssid:
        return "Which WiFi network?"
    if sys.platform == "win32":
        if password:
            xml = (f'<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">'
                   f'<name>{_esc(ssid)}</name><SSIDConfig><SSID><name>{_esc(ssid)}</name></SSID></SSIDConfig>'
                   f'<connectionType>ESS</connectionType><connectionMode>auto</connectionMode>'
                   f'<MSM><security><authEncryption><authentication>WPA2PSK</authentication>'
                   f'<encryption>AES</encryption><useOneX>false</useOneX></authEncryption>'
                   f'<sharedKey><keyType>passPhrase</keyType><protected>false</protected>'
                   f'<keyMaterial>{_esc(password)}</keyMaterial></sharedKey></security></MSM></WLANProfile>')
            f = Path(tempfile.gettempdir()) / "mlv_wifi.xml"
            f.write_text(xml, encoding="utf-8")
            _run(["netsh", "wlan", "add", "profile", f"filename={f}"])
            f.unlink(missing_ok=True)
        return _run(["netsh", "wlan", "connect", f"name={ssid}"]).strip()
    if sys.platform == "darwin":
        return _run(["networksetup", "-setairportnetwork", "en0", ssid, password]).strip() or "Requested."
    cmd = ["nmcli", "dev", "wifi", "connect", ssid] + (["password", password] if password else [])
    return _run(cmd, 40).strip()


# ── consent-based device link ────────────────────────────────────────────────
def _links() -> dict:
    try:
        return json.loads(_STORE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(d: dict) -> None:
    _STORE.parent.mkdir(parents=True, exist_ok=True)
    _STORE.write_text(json.dumps(d, indent=2), encoding="utf-8")


def _rpc(host: str, payload: dict, timeout: float) -> dict:
    ip = ipaddress.ip_address(host)
    if not (ip.is_private or ip.is_loopback):
        raise ValueError("Only devices on your private network are allowed.")
    with socket.create_connection((host, LINK_PORT), timeout=6) as c:
        c.settimeout(timeout)
        c.sendall((json.dumps(payload) + "\n").encode())
        data = b""
        while not data.endswith(b"\n"):
            chunk = c.recv(1 << 16)
            if not chunk:
                break
            data += chunk
    return json.loads(data.decode())


def _resolve(target: str) -> str | None:
    """Accept an IP, or a name/hostname we have seen or paired with."""
    try:
        ipaddress.ip_address(target)
        return target
    except ValueError:
        pass
    for host, info in _links().items():
        if target.lower() in (info.get("name", "").lower(), host):
            return host
    return None


def _request(target: str, me: str) -> str:
    host = _resolve(target)
    if not host:
        return "Give the device's IP address (run scan to find it)."
    want = ["message", "open_url", "lock", "info", "screenshot", "input"]
    try:
        r = _rpc(host, {"type": "pair_request", "from": me, "want": want}, timeout=100)
    except Exception as e:
        return (f"Could not reach {host}: {e}. Is link_agent.py running on that device "
                f"(python link_agent.py)?")
    if r.get("type") == "pair_accept":
        d = _links()
        d[host] = {"token": r["token"], "granted": r.get("granted", []),
                   "name": r.get("host", host), "at": time.time()}
        _save(d)
        return (f"{r.get('host', host)} accepted. I can now: {', '.join(r.get('granted', []))}.")
    return f"{host} declined the request, so I have not connected."


def _send(target: str, cmd: str, value: str) -> str:
    host = _resolve(target)
    d = _links()
    if not host or host not in d:
        return "That device has not accepted a request. Use link_request first."
    token = d[host]["token"]
    ts = str(time.time())
    sig = hmac.new(token.encode(), f"{ts}|{cmd}|{value}".encode(), hashlib.sha256).hexdigest()
    try:
        r = _rpc(host, {"type": "cmd", "token": token, "ts": ts, "cmd": cmd,
                        "value": value, "sig": sig}, timeout=30)
    except Exception as e:
        return f"Could not reach {host}: {e}"
    if r.get("data_b64"):
        out = Path.home() / "Downloads" / f"screen_{host.replace('.', '_')}_{int(time.time())}.png"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(r["data_b64"]))
        return f"{r.get('result', 'Done.')} Saved to {out}"
    if cmd == "unpair":
        d.pop(host, None); _save(d)
    return str(r.get("result", "Done."))


def network(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "scan")).lower().strip()
    host = str(parameters.get("host", "") or parameters.get("name", "") or "").strip()
    if player:
        try:
            player.write_log(f"[network] {a} {host}")
        except Exception:
            pass
    if a == "scan":
        return _scan()
    if a == "wifi_list":
        return _wifi_list()
    if a == "wifi_connect":
        return _wifi_connect(str(parameters.get("ssid", "")), str(parameters.get("password", "")))
    if a == "link_request":
        me = str(parameters.get("from", "") or socket.gethostname())
        return _request(host, me)
    if a == "link_send":
        return _send(host, str(parameters.get("cmd", "")), str(parameters.get("value", "") or ""))
    if a == "link_list":
        d = _links()
        return "\n".join(f"{h} ({i.get('name')}): {', '.join(i.get('granted', []))}"
                         for h, i in d.items()) or "No devices have accepted yet."
    if a == "link_forget":
        h = _resolve(host); d = _links()
        if h in d:
            _send(h, "unpair", "")
            d.pop(h, None); _save(d)
            return f"Forgot {h}."
        return "No such device."
    return "Use: scan | wifi_list | wifi_connect | link_request | link_send | link_list | link_forget"


TOOL = {
    "name": "network",
    "description": (
        "Scans the user's local network for devices (action=scan), lists nearby WiFi "
        "(wifi_list) and joins a WiFi network (wifi_connect with ssid and password). To control "
        "another computer: action=link_request with its IP sends a connection request; its owner "
        "must press Yes in the Mark-LV Link window on that device. Only after it says accepted, "
        "use link_send with cmd = message | open_url | lock | info | screenshot (value = the text "
        "or URL). Never claim control before the device accepted; if it declined, say so."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":   {"type": "STRING", "description": "scan | wifi_list | wifi_connect | link_request | link_send | link_list | link_forget"},
            "host":     {"type": "STRING", "description": "Device IP address or saved name"},
            "ssid":     {"type": "STRING", "description": "WiFi network name"},
            "password": {"type": "STRING", "description": "WiFi password"},
            "cmd":      {"type": "STRING", "description": "link_send command: message | open_url | lock | info | screenshot | type_text | key | click"},
            "value":    {"type": "STRING", "description": "Text, URL, key combo or 'x y' for the command"},
        },
        "required": ["action"],
    },
    "handler": network,
}

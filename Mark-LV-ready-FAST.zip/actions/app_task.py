"""
actions/app_task.py — do things in desktop apps precisely, and prove it.

Rules this tool lives by:
  * It never types into a window it has not confirmed is in front.
  * It re-checks the front window after typing, and reads the text back from the
    editor to confirm it landed.
  * When anything fails it says so plainly. It never reports success it did not see.

Best path for "write this code/text in Notepad": action=write_in_editor. It saves
the content to a file, opens that file in the editor, and checks the file on disk —
no keystrokes, so nothing can go to the wrong window.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

from core import winctl

_NOWIN = 0x08000000 if sys.platform == "win32" else 0
_EDITORS = ("notepad", "untitled", "visual studio code", "sublime", "wordpad", "textedit",
            "gedit", "kate", "mousepad", "notepad++")
_APP_EXE = {
    "notepad": "notepad.exe", "calculator": "calc.exe", "calc": "calc.exe",
    "paint": "mspaint.exe", "wordpad": "write.exe", "explorer": "explorer.exe",
    "cmd": "cmd.exe", "powershell": "powershell.exe", "word": "winword.exe",
    "excel": "excel.exe", "powerpoint": "powerpnt.exe", "chrome": "chrome.exe",
    "edge": "msedge.exe", "vscode": "code.cmd", "code": "code.cmd",
}
_HINT = {"calc": "Calculator", "calculator": "Calculator", "paint": "Paint", "vscode": "Visual Studio Code",
         "code": "Visual Studio Code", "word": "Word", "excel": "Excel", "powerpoint": "PowerPoint",
         "chrome": "Chrome", "edge": "Edge", "explorer": "File Explorer", "cmd": "Command Prompt",
         "powershell": "PowerShell"}
_EXT = {"python": ".py", "py": ".py", "javascript": ".js", "js": ".js", "html": ".html", "css": ".css",
        "java": ".java", "c": ".c", "cpp": ".cpp", "c++": ".cpp", "json": ".json", "text": ".txt",
        "sql": ".sql", "bash": ".sh", "csharp": ".cs", "c#": ".cs", "go": ".go", "rust": ".rs"}


def _pyauto():
    import pyautogui
    pyautogui.FAILSAFE = False
    return pyautogui


def _clip_set(text: str) -> None:
    import pyperclip
    pyperclip.copy(text)


def _clip_get() -> str:
    import pyperclip
    return pyperclip.paste()


def _mod() -> str:
    return "command" if sys.platform == "darwin" else "ctrl"


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").replace("\r\n", "\n")).strip()


# ── opening ──────────────────────────────────────────────────────────────────
def _launch(app: str, arg: str = "") -> None:
    key = app.lower().strip()
    exe = _APP_EXE.get(key, app)
    if sys.platform == "win32":
        cmd = ["cmd", "/c", "start", "", exe] + ([arg] if arg else [])
        subprocess.Popen(cmd, creationflags=_NOWIN)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-a", app] + ([arg] if arg else []))
    else:
        cand = {"notepad": "gedit", "calculator": "gnome-calculator"}.get(key, app)
        subprocess.Popen([cand] + ([arg] if arg else []))


def _open(app: str, hint: str = "") -> str:
    if not app:
        return "Which app should I open?"
    want = hint or _HINT.get(app.lower(), app)
    before = winctl.active_title()
    try:
        _launch(app)
    except Exception as e:
        return f"NOT opened: could not start '{app}' ({e})."
    if not winctl.wait_for_window(want, timeout=12):
        return (f"NOT confirmed: I started '{app}' but no window titled '{want}' appeared in 12 seconds. "
                f"The front window is still '{winctl.active_title() or before}'.")
    ok, act = winctl.focus_verified(want)
    if not ok:
        return f"'{app}' is open but I could not bring it to the front (front window: '{act}')."
    return f"Opened {app}; confirmed it is the front window ('{act}')."


# ── typing ───────────────────────────────────────────────────────────────────
def _type(target: str, text: str, press_enter: bool, verify: bool) -> str:
    if not target:
        return "NOT typed: tell me which window to type into (target)."
    if not text:
        return "NOT typed: no text given."
    ok, act = winctl.focus_verified(target)
    if not ok:
        return (f"NOT typed: could not bring '{target}' to the front. The front window is '{act}', "
                f"so I did nothing there.")
    try:
        pa = _pyauto()
        _clip_set(text)
        time.sleep(0.12)
        if not winctl.is_front(target):
            return f"NOT typed: focus moved to '{winctl.active_title()}' just before pasting."
        pa.hotkey(_mod(), "v")
        time.sleep(0.25)
        after = winctl.active_title()
        if target.lower() not in after.lower():
            return (f"WARNING: focus moved to '{after}' while typing; the text may have gone there. "
                    f"Check before trusting it.")
        if press_enter:
            pa.press("enter")
        note = ""
        if verify and any(e in act.lower() for e in _EDITORS):
            pa.hotkey(_mod(), "a"); time.sleep(0.1)
            pa.hotkey(_mod(), "c"); time.sleep(0.2)
            doc = _clip_get()
            pa.hotkey(_mod(), "end")                 # drop the selection
            if _norm(text) in _norm(doc):
                note = " Read back from the editor: the text is there."
            else:
                return f"UNVERIFIED: typed into '{act}' but the editor's content does not match what I sent."
        return f"Typed {len(text)} characters into '{act}'.{note}"
    except ImportError as e:
        return f"NOT typed: missing package ({e}). pip install pyautogui pyperclip"
    except Exception as e:
        return f"NOT typed: {e}"


def _write_in_editor(content: str, filename: str, app: str, language: str) -> str:
    if not content:
        return "Nothing to write."
    name = filename or ("code" + _EXT.get((language or "").lower(), ".txt"))
    if not Path(name).suffix:
        name += _EXT.get((language or "").lower(), ".txt")
    folder = Path.home() / "Desktop"
    if not folder.exists():
        folder = Path.home()
    path = folder / Path(name).name
    path.write_text(content, encoding="utf-8")
    if path.read_text(encoding="utf-8") != content:
        return f"NOT done: the file I saved at {path} does not match what I wrote."
    editor = (app or "notepad").lower()
    try:
        if sys.platform == "win32" and editor == "notepad":
            subprocess.Popen(["notepad.exe", str(path)], creationflags=_NOWIN)
        else:
            _launch(editor, str(path))
    except Exception as e:
        return f"File saved at {path}, but I could not start '{editor}' ({e})."
    hint = path.name
    if not winctl.wait_for_window(hint, timeout=12):
        return (f"File saved at {path}, but I could not confirm an editor window titled '{hint}' opened. "
                f"Front window: '{winctl.active_title()}'.")
    ok, act = winctl.focus_verified(hint)
    return (f"Wrote {len(content)} characters to {path} and opened it in {editor}"
            f"{'; confirmed it is the front window (' + act + ')' if ok else '; it is open but not in front (front: ' + act + ')'}.")


# ── reading and clicking controls (Windows UI Automation) ────────────────────
def _uia_window(target: str):
    from pywinauto import Desktop
    for w in Desktop(backend="uia").windows():
        try:
            if target.lower() in w.window_text().lower():
                return w
        except Exception:
            continue
    return None


def _ui(action: str, target: str, control: str) -> str:
    if sys.platform != "win32":
        return "ui_* actions use Windows UI Automation and only work on Windows."
    try:
        w = _uia_window(target)
    except ImportError:
        return "ui_* needs pywinauto. Run: pip install pywinauto"
    if w is None:
        return f"No window titled '{target}' found."
    try:
        if action == "ui_list":
            rows = []
            for c in w.descendants():
                t = (c.window_text() or "").strip()
                if t:
                    rows.append(f"{c.element_info.control_type}: {t[:60]}")
                if len(rows) >= 80:
                    break
            return "\n".join(rows) or "No named controls found."
        if action == "ui_text":
            parts = []
            for c in w.descendants():
                t = (c.window_text() or "").strip()
                try:
                    if c.element_info.control_type in ("Edit", "Document"):
                        t = (c.get_value() or t) if hasattr(c, "get_value") else t
                except Exception:
                    pass
                if t:
                    parts.append(t)
            return "\n".join(dict.fromkeys(parts))[:4000] or "No readable text."
        if action == "ui_click":
            for c in w.descendants():
                if control.lower() in (c.window_text() or "").lower():
                    try:
                        c.invoke()
                    except Exception:
                        c.click_input()
                    return f"Clicked '{c.window_text()}' in '{w.window_text()}'."
            return f"No control named '{control}' in '{w.window_text()}'."
    except Exception as e:
        return f"{action} failed: {e}"
    return "Unknown ui action."


def app_task(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "")).lower().strip()
    target = str(parameters.get("target", "") or parameters.get("app", "") or "").strip()
    text = str(parameters.get("text", "") or "")
    if player:
        try:
            player.write_log(f"[app_task] {a} {target}")
        except Exception:
            pass
    if a == "list":
        return "\n".join(winctl.list_windows()[:60]) or "No windows found."
    if a == "active":
        return f"Front window: '{winctl.active_title()}'"
    if a == "focus":
        ok, act = winctl.focus_verified(target)
        return (f"Confirmed: '{act}' is now in front." if ok
                else f"FAILED: '{target}' is not in front. The front window is '{act}'.")
    if a == "open":
        return _open(str(parameters.get("app", "") or target), str(parameters.get("hint", "") or ""))
    if a == "type":
        return _type(target, text, str(parameters.get("press_enter", "")).lower() in ("true", "1", "yes"),
                     str(parameters.get("verify", "true")).lower() not in ("false", "0", "no"))
    if a == "open_and_type":
        app = str(parameters.get("app", "") or target)
        r = _open(app, str(parameters.get("hint", "") or ""))
        if "Opened" not in r or "confirmed" not in r.lower():
            return r + " I did not type anything."
        hint = str(parameters.get("hint", "") or _HINT.get(app.lower(), app))
        return r + " " + _type(hint, text, False, True)
    if a == "write_in_editor":
        return _write_in_editor(text, str(parameters.get("filename", "") or ""),
                                str(parameters.get("app", "") or "notepad"),
                                str(parameters.get("language", "") or ""))
    if a in ("ui_list", "ui_text", "ui_click"):
        return _ui(a, target, str(parameters.get("control", "") or ""))
    return ("Unknown action. Use: list | active | focus | open | type | open_and_type | "
            "write_in_editor | ui_list | ui_text | ui_click")


TOOL = {
    "name": "app_task",
    "description": (
        "PRECISE desktop work that confirms every step. Use this instead of computer_control whenever "
        "text must end up in a specific app. For 'write/type code or text in Notepad (or another "
        "editor)' use action=write_in_editor with the full text in `text` (and `filename`, `language`): "
        "it saves the file and opens it in the editor with no typing at all. Other actions: open (app), "
        "focus (target = part of the window title), type (target window + text; refuses unless that "
        "window is verifiably in front), open_and_type, active, list, and Windows-only ui_list / "
        "ui_text / ui_click to read a window's text and click its buttons by name without vision. "
        "Report exactly what the result says — if it says NOT typed or FAILED, tell the user that, "
        "never claim success."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":   {"type": "STRING", "description": "write_in_editor | open | focus | type | open_and_type | active | list | ui_list | ui_text | ui_click"},
            "app":      {"type": "STRING", "description": "App to open, e.g. notepad, calculator, word"},
            "target":   {"type": "STRING", "description": "Part of the window title to act on, e.g. Notepad"},
            "text":     {"type": "STRING", "description": "The exact text or code to write"},
            "filename": {"type": "STRING", "description": "File name for write_in_editor, e.g. hello.py"},
            "language": {"type": "STRING", "description": "Language for write_in_editor, picks the file extension"},
            "control":  {"type": "STRING", "description": "Button/control name for ui_click"},
            "press_enter": {"type": "BOOLEAN", "description": "Press Enter after typing"},
        },
        "required": ["action"],
    },
    "handler": app_task,
}

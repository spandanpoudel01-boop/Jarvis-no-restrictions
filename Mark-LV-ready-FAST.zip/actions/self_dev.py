"""
actions/self_dev.py — the assistant looks after itself.

  diagnose   Probes what it needs to watch the desktop and drive apps (screen
             capture, window list, process list, input control, permissions,
             session type, network, microphone, optional tools) and reports each
             problem together with the exact fix.
  list/read  Browse its own source.
  patch/write  Change its own code ON THE USER'S REQUEST. Every change is backed
             up first, validated (Python must compile, JSON must parse) and
             rolled back automatically if validation fails.
  backups/rollback  Undo any change.
  relaunch   Restart the program on the new code. The memory/ folder is never
             edited by this tool and is snapshotted before every restart, so all
             old memory is kept.

The model is told (prompt.txt / tool description) to use patch, write and
relaunch only when the user has asked for them.
"""
from __future__ import annotations

import ast
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
BACKUPS = BASE / "backups"
_PROTECTED = ("memory",)              # never modified by patch/write
_SKIP_DIRS = {"__pycache__", "backups", ".git"}


# ── helpers ──────────────────────────────────────────────────────────────────
def _resolve(rel: str) -> Path | None:
    try:
        p = (BASE / rel).resolve()
        p.relative_to(BASE.resolve())
        return p
    except Exception:
        return None


def _protected(p: Path) -> bool:
    rel = p.relative_to(BASE.resolve()).parts
    return bool(rel) and rel[0] in _PROTECTED


def _validate(p: Path) -> str | None:
    """None if the file is acceptable, else a description of the problem."""
    try:
        if p.suffix == ".py":
            compile(p.read_text(encoding="utf-8"), str(p), "exec")
        elif p.suffix == ".json":
            json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return str(e)
    return None


def _backup(p: Path) -> Path | None:
    if not p.exists():
        return None
    stamp = time.strftime("%Y%m%d-%H%M%S")
    rel = p.relative_to(BASE.resolve())
    dst = BACKUPS / stamp / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dst)
    return dst


def _latest_backup(rel: Path) -> Path | None:
    if not BACKUPS.exists():
        return None
    for d in sorted((x for x in BACKUPS.iterdir() if x.is_dir()), reverse=True):
        cand = d / rel
        if cand.exists():
            return cand
    return None


# ── diagnose ─────────────────────────────────────────────────────────────────
def _probe(name: str, fn, fix: str) -> str:
    try:
        detail = fn()
        return f"OK    {name}" + (f" — {detail}" if detail else "")
    except Exception as e:
        return f"FAIL  {name}: {type(e).__name__}: {str(e)[:120]}\n      FIX: {fix}"


def _diagnose() -> str:
    sysname = platform.system()
    lines = [f"System: {sysname} {platform.release()}, Python {platform.python_version()}"]

    # Linux Wayland is the #1 reason screen/app control silently fails.
    if sysname == "Linux":
        sess = os.environ.get("XDG_SESSION_TYPE", "").lower()
        if sess == "wayland":
            lines.append("FAIL  Display session is Wayland: screen capture and input injection "
                         "are blocked for normal programs.\n      FIX: log out and choose "
                         "'Ubuntu on Xorg' / 'X11' on the login screen, then relaunch.")
        elif not os.environ.get("DISPLAY"):
            lines.append("FAIL  No DISPLAY: not running in a desktop session.\n"
                         "      FIX: start from the desktop, not an SSH/TTY session.")
        else:
            lines.append(f"OK    Display session: {sess or 'x11'}")

    if sysname == "Windows":
        try:
            import ctypes
            admin = bool(ctypes.windll.shell32.IsUserAnAdmin())  # type: ignore[attr-defined]
            lines.append("OK    Running as administrator" if admin else
                         "NOTE  Not running as administrator: it cannot click inside apps that are "
                         "running as administrator.\n      FIX: right-click the shortcut -> Run as administrator.")
        except Exception:
            pass

    if sysname == "Darwin":
        lines.append("NOTE  macOS needs Accessibility AND Screen Recording permission for your "
                     "terminal/Python.\n      FIX: System Settings -> Privacy & Security -> "
                     "Accessibility, and Screen Recording -> tick Terminal (or Python), then relaunch.")

    # Python packages
    pkgs = [("pyautogui", "pyautogui"), ("mss", "mss"), ("psutil", "psutil"),
            ("pygetwindow", "pygetwindow"), ("pyperclip", "pyperclip"), ("PIL", "pillow"),
            ("cv2", "opencv-python"), ("sounddevice", "sounddevice"),
            ("send2trash", "send2trash"), ("serial", "pyserial"), ("PyQt6", "PyQt6")]
    import importlib
    missing = []
    for mod, pipname in pkgs:
        try:
            importlib.import_module(mod)
        except Exception:
            missing.append(pipname)
    lines.append("OK    All Python packages present" if not missing else
                 f"FAIL  Missing packages: {', '.join(missing)}\n      FIX: pip install {' '.join(missing)}")

    # Functional probes: do the capabilities actually work right now?
    def screen():
        import mss
        with mss.mss() as s:
            m = s.monitors[1]
            s.grab({"left": m["left"], "top": m["top"], "width": 8, "height": 8})
            return f"{m['width']}x{m['height']}"
    lines.append(_probe("Screen capture (background monitoring)", screen,
                        "install mss; on Linux use an X11 session; on macOS grant Screen Recording."))

    def inputs():
        import pyautogui
        w, h = pyautogui.size()
        x, y = pyautogui.position()
        return f"screen {w}x{h}, mouse at {x},{y}"
    lines.append(_probe("Mouse/keyboard control", inputs,
                        "pip install pyautogui; on Linux also install python3-xlib and use X11; "
                        "on macOS grant Accessibility."))

    def active_window():
        if sysname == "Linux":
            r = subprocess.run(["xdotool", "getactivewindow", "getwindowname"],
                               capture_output=True, text=True, timeout=5)
            if r.returncode != 0:
                raise RuntimeError(r.stderr.strip() or "xdotool failed")
            return r.stdout.strip()[:60]
        import pygetwindow as gw
        w = gw.getActiveWindow()
        return (w.title if w else "(none)")[:60]
    lines.append(_probe("Active-window detection (knowing which app you are in)", active_window,
                        "Linux: sudo apt install xdotool; Windows/macOS: pip install pygetwindow "
                        "(macOS also needs pyobjc)."))

    def procs():
        import psutil
        return f"{len(psutil.pids())} processes visible"
    lines.append(_probe("Process list (what apps are running)", procs, "pip install psutil"))

    def opener():
        exe = {"Windows": "cmd", "Darwin": "open", "Linux": "xdg-open"}[sysname]
        if sysname != "Windows" and not shutil.which(exe):
            raise RuntimeError(f"{exe} not found")
        return exe
    lines.append(_probe("App launcher", opener,
                        "Linux: sudo apt install xdg-utils"))

    def net():
        socket.create_connection(("generativelanguage.googleapis.com", 443), timeout=5).close()
        return "Gemini API reachable"
    lines.append(_probe("Network to the AI service", net,
                        "check internet/VPN/firewall; the assistant needs generativelanguage.googleapis.com:443."))

    def mic():
        import sounddevice as sd
        ins = [d for d in sd.query_devices() if d["max_input_channels"] > 0]
        if not ins:
            raise RuntimeError("no microphone found")
        return f"{len(ins)} input device(s)"
    lines.append(_probe("Microphone", mic,
                        "plug in / enable a microphone and allow microphone access in OS privacy settings."))

    try:
        from config import get_config
        key = get_config().get("gemini_api_key")
        lines.append("OK    Gemini API key configured" if key else
                     "FAIL  No Gemini API key.\n      FIX: put gemini_api_key in config/api_keys.json.")
    except Exception as e:
        lines.append(f"FAIL  Could not read config: {e}")

    lines.append("OK    adb found (phone control available)" if shutil.which("adb") else
                 "NOTE  adb not installed: phone control and calls via phone are unavailable.\n"
                 "      FIX: install Android platform-tools and add it to PATH.")

    try:
        from core.crashlog import tail
        recent = tail(18)
        if recent:
            lines.append("NOTE  Recent errors from logs/crash.log (newest last):\n" +
                         "\n".join("      " + l for l in recent.splitlines()))
    except Exception:
        pass

    fails = sum(1 for l in lines if l.startswith("FAIL"))
    lines.append(f"\nSummary: {fails} problem(s) found." if fails else "\nSummary: no problems found.")
    return "\n".join(lines)


# ── source browsing / editing ────────────────────────────────────────────────
def _list() -> str:
    out = []
    for p in sorted(BASE.rglob("*")):
        if p.is_file() and not (set(p.relative_to(BASE).parts) & _SKIP_DIRS) \
                and p.suffix in (".py", ".txt", ".json", ".html"):
            out.append(str(p.relative_to(BASE)))
    return "\n".join(out)


def _read(rel: str, start: int, end: int) -> str:
    p = _resolve(rel)
    if p is None or not p.is_file():
        return f"No such file inside the project: {rel}"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    a = max(1, start or 1)
    b = min(len(lines), end or a + 199)
    body = "\n".join(f"{i}: {lines[i - 1]}" for i in range(a, b + 1))
    return f"{rel} (lines {a}-{b} of {len(lines)})\n{body}"


def _apply(p: Path, new_text: str, what: str) -> str:
    bak = _backup(p)
    existed = p.exists()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(new_text, encoding="utf-8")
    err = _validate(p)
    if err:
        if bak:
            shutil.copy2(bak, p)
        elif not existed:
            p.unlink(missing_ok=True)
        return f"{what} REJECTED and rolled back — it would not compile/parse: {err}"
    return (f"{what} applied to {p.relative_to(BASE.resolve())}. "
            f"Backup kept ({'new file' if not bak else bak.relative_to(BACKUPS).parts[0]}). "
            f"Restart with action=relaunch to run the new code.")


def _patch(rel: str, old: str, new: str) -> str:
    p = _resolve(rel)
    if p is None:
        return "That path is outside the project."
    if _protected(p):
        return "The memory folder is protected — I never edit it, so your memory stays safe."
    if not p.is_file():
        return f"No such file: {rel}"
    text = p.read_text(encoding="utf-8")
    n = text.count(old)
    if not old or n != 1:
        return f"Patch NOT applied: the text to replace must appear exactly once (found {n})."
    return _apply(p, text.replace(old, new, 1), "Patch")


def _write(rel: str, content: str) -> str:
    p = _resolve(rel)
    if p is None:
        return "That path is outside the project."
    if _protected(p):
        return "The memory folder is protected — I never edit it, so your memory stays safe."
    return _apply(p, content, "Write")


def _backups() -> str:
    if not BACKUPS.exists():
        return "No backups yet."
    rows = []
    for d in sorted((x for x in BACKUPS.iterdir() if x.is_dir()), reverse=True)[:15]:
        files = [str(f.relative_to(d)) for f in d.rglob("*") if f.is_file()]
        rows.append(f"{d.name}: {', '.join(files[:6])}")
    return "\n".join(rows)


def _rollback(rel: str) -> str:
    p = _resolve(rel)
    if p is None:
        return "That path is outside the project."
    if _protected(p):
        return "The memory folder is protected."
    b = _latest_backup(p.relative_to(BASE.resolve()))
    if b is None:
        return f"No backup found for {rel}."
    _backup(p)                       # so the rollback can itself be undone
    shutil.copy2(b, p)
    return f"{rel} restored from the backup taken on {b.relative_to(BACKUPS).parts[0]}."


# ── relaunch ─────────────────────────────────────────────────────────────────
def _relaunch(player=None) -> str:
    bad = []
    for p in BASE.rglob("*.py"):
        if set(p.relative_to(BASE).parts) & _SKIP_DIRS:
            continue
        err = _validate(p)
        if err:
            bad.append(f"{p.relative_to(BASE)}: {err[:100]}")
    if bad:
        return ("Relaunch CANCELLED — these files do not compile, so the new code would not start:\n"
                + "\n".join(bad[:5]) + "\nFix them or use action=rollback first.")
    # keep all old memory: snapshot before restarting
    mem = BASE / "memory"
    if mem.exists():
        snap = BACKUPS / ("memory-" + time.strftime("%Y%m%d-%H%M%S"))
        try:
            shutil.copytree(mem, snap, ignore=shutil.ignore_patterns("__pycache__"))
        except Exception as e:
            return f"Relaunch CANCELLED — could not snapshot memory first: {e}"
    py = sys.executable
    main = str(BASE / "main.py")
    if sys.platform == "win32":
        cmd = f'ping -n 5 127.0.0.1 >nul & "{py}" "{main}"'
        subprocess.Popen(["cmd", "/c", cmd], cwd=str(BASE),
                         creationflags=0x00000008 | 0x00000200)   # DETACHED | NEW_GROUP
    else:
        subprocess.Popen(["sh", "-c", f'sleep 4; exec "{py}" "{main}"'], cwd=str(BASE),
                         start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if player:
        try:
            player.write_log("SYS: Restarting on the new code — memory is kept.")
        except Exception:
            pass
    # give the assistant a moment to say goodbye, then quit this instance
    threading.Timer(3.0, lambda: os._exit(0)).start()
    return ("Restarting now on the new code. All memory is kept (snapshot saved). "
            "Tell the user in one short sentence that you will be back in a few seconds.")


def self_dev(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "diagnose")).lower().strip()
    path = str(parameters.get("path", "") or "")
    if player:
        try:
            player.write_log(f"[self_dev] {a} {path}")
        except Exception:
            pass
    if a == "diagnose":
        return _diagnose()
    if a == "list":
        return _list()
    if a == "read":
        return _read(path, int(parameters.get("start", 1) or 1), int(parameters.get("end", 0) or 0))
    if a == "patch":
        return _patch(path, str(parameters.get("old", "")), str(parameters.get("new", "")))
    if a == "write":
        return _write(path, str(parameters.get("content", "")))
    if a == "backups":
        return _backups()
    if a == "rollback":
        return _rollback(path)
    if a == "relaunch":
        return _relaunch(player)
    return "Unknown action. Use: diagnose | list | read | patch | write | backups | rollback | relaunch"


TOOL = {
    "name": "self_dev",
    "description": (
        "Self-care for the assistant. action=diagnose checks whether it can watch the desktop and "
        "use apps (screen capture, window/process lists, mouse/keyboard, permissions, network, "
        "microphone) and returns each problem with its fix — use it whenever something about "
        "monitoring the background or opening/using apps fails or the user asks what is wrong, "
        "and tell the user the fixes in plain words. action=list/read browses its own source. "
        "action=patch (path, old, new) / write (path, content) change its own code, and "
        "action=relaunch restarts it on the new code with memory kept; use patch, write and "
        "relaunch ONLY when the user asked for a change. Every edit is backed up and validated, "
        "and action=rollback (path) undoes it."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":  {"type": "STRING", "description": "diagnose | list | read | patch | write | backups | rollback | relaunch"},
            "path":    {"type": "STRING", "description": "File path relative to the project, e.g. actions/open_app.py"},
            "old":     {"type": "STRING", "description": "patch: exact existing text (must occur once)"},
            "new":     {"type": "STRING", "description": "patch: replacement text"},
            "content": {"type": "STRING", "description": "write: full new file content"},
            "start":   {"type": "INTEGER", "description": "read: first line"},
            "end":     {"type": "INTEGER", "description": "read: last line"},
        },
        "required": ["action"],
    },
    "handler": self_dev,
}

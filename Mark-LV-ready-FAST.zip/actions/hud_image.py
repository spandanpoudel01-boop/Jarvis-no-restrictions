"""actions/hud_image.py — let the user choose what fills the middle of the interface."""
from pathlib import Path


def hud_image(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "set")).lower().strip()
    if player is None:
        return "The interface is not available."
    if a == "set":
        path = Path(str(parameters.get("path", ""))).expanduser()
        if not path.is_file():
            return f"I cannot find the picture at {path}."
        if path.suffix.lower() not in (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".gif"):
            return "That file is not a picture I can use."
        player.set_hud_image(str(path))
        return f"Done — {path.name} is now the picture at the centre of the interface."
    if a in ("logo", "custom"):
        player.set_hud_style(a)
        return f"Interface switched to the {a}."
    return "Use action=set with a path, or action=logo / custom."


TOOL = {
    "name": "hud_image",
    "description": (
        "Changes the centrepiece of the interface. action=set with a picture path makes any photo "
        "the interface picture (use the path from an uploaded image); action=logo shows the Trinity "
        "logo; action=custom returns to the last chosen photo."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "set | logo | custom"},
            "path":   {"type": "STRING", "description": "Path of the picture (for action=set)"},
        },
        "required": ["action"],
    },
    "handler": hud_image,
}

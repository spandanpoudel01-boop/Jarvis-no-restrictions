"""
actions/devices.py — Bluetooth, USB and serial (wired) device control.

Auto-discovered via the TOOL dict at the bottom. Everything shells out to the
tool the OS already ships, so there is nothing extra to install except
`pyserial` for serial-port I/O (pip install pyserial).

  Linux   bluetoothctl, lsusb
  macOS   blueutil (brew install blueutil), system_profiler
  Windows PowerShell PnP cmdlets (list/paired); connecting a new device opens
          the Bluetooth settings page, because Windows has no CLI for pairing.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys

_MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$")


def _run(cmd: list[str] | str, timeout: int = 25, shell: bool = False) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=shell,
                           creationflags=0x08000000 if sys.platform == "win32" else 0)
        out = (r.stdout or "") + (r.stderr or "")
        return out.strip() or "(no output)"
    except FileNotFoundError:
        return f"Command not found: {cmd[0] if isinstance(cmd, list) else cmd}"
    except subprocess.TimeoutExpired:
        return "Timed out."
    except Exception as e:
        return f"Failed: {e}"


def _ps(script: str) -> str:
    return _run(["powershell", "-NoProfile", "-Command", script], timeout=40)


def _plat() -> str:
    return {"win32": "windows", "darwin": "mac"}.get(sys.platform, "linux")


# ── Bluetooth ────────────────────────────────────────────────────────────────
def _bt(action: str, address: str, name: str) -> str:
    plat = _plat()
    target = address or name
    if action in ("connect", "disconnect", "pair", "trust") and not _MAC_RE.match(address or ""):
        # Resolve a friendly name to an address from the paired list.
        if plat == "linux" and name:
            for line in _run(["bluetoothctl", "devices"]).splitlines():
                m = re.match(r"Device\s+(\S+)\s+(.*)", line)
                if m and name.lower() in m.group(2).lower():
                    address = m.group(1)
                    break
        elif plat == "mac" and name and shutil.which("blueutil"):
            for line in _run(["blueutil", "--paired"]).splitlines():
                m = re.search(r"address: ([0-9a-f-]+).*name: \"(.*?)\"", line)
                if m and name.lower() in m.group(2).lower():
                    address = m.group(1)
                    break
    if action in ("connect", "disconnect", "pair", "trust") and not _MAC_RE.match(address or ""):
        if plat == "windows":
            subprocess.Popen(["cmd", "/c", "start", "ms-settings:bluetooth"])
            return "Windows cannot pair from a script; I opened Bluetooth settings."
        return f"No paired device matches '{target}'. Say 'scan bluetooth' first."

    if plat == "linux":
        if not shutil.which("bluetoothctl"):
            return "bluetoothctl is not installed (sudo apt install bluez)."
        cmds = {
            "power_on":  ["bluetoothctl", "power", "on"],
            "power_off": ["bluetoothctl", "power", "off"],
            "paired":    ["bluetoothctl", "devices", "Paired"],
            "connect":   ["bluetoothctl", "connect", address],
            "disconnect":["bluetoothctl", "disconnect", address],
            "pair":      ["bluetoothctl", "pair", address],
            "trust":     ["bluetoothctl", "trust", address],
        }
        if action == "scan":
            _run("bluetoothctl --timeout 8 scan on", timeout=15, shell=True)
            return _run(["bluetoothctl", "devices"])
        return _run(cmds[action], timeout=30) if action in cmds else f"Unsupported: {action}"

    if plat == "mac":
        if not shutil.which("blueutil"):
            return "blueutil is not installed (brew install blueutil)."
        cmds = {
            "power_on":  ["blueutil", "--power", "1"],
            "power_off": ["blueutil", "--power", "0"],
            "paired":    ["blueutil", "--paired"],
            "connect":   ["blueutil", "--connect", address],
            "disconnect":["blueutil", "--disconnect", address],
            "pair":      ["blueutil", "--pair", address],
        }
        if action == "scan":
            return _run(["blueutil", "--inquiry", "8"], timeout=20)
        return _run(cmds[action]) if action in cmds else f"Unsupported: {action}"

    # Windows
    if action in ("paired", "scan"):
        return _ps("Get-PnpDevice -Class Bluetooth | Select-Object Status,FriendlyName | Format-Table -AutoSize | Out-String")
    subprocess.Popen(["cmd", "/c", "start", "ms-settings:bluetooth"])
    return "Opened Windows Bluetooth settings; Windows offers no scripted connect/power."


# ── USB / wired ──────────────────────────────────────────────────────────────
def _usb() -> str:
    plat = _plat()
    if plat == "linux":
        return _run(["lsusb"]) if shutil.which("lsusb") else "lsusb not installed (sudo apt install usbutils)."
    if plat == "mac":
        return _run(["system_profiler", "SPUSBDataType"], timeout=40)
    return _ps("Get-PnpDevice -PresentOnly -Class USB | Select-Object Status,FriendlyName | Format-Table -AutoSize | Out-String")


def _serial(action: str, port: str, baud: int, data: str, timeout: float) -> str:
    try:
        import serial
        from serial.tools import list_ports
    except ImportError:
        return "pyserial is not installed. Run: pip install pyserial"
    if action == "serial_list":
        ports = list(list_ports.comports())
        return "\n".join(f"{p.device} — {p.description}" for p in ports) or "No serial ports found."
    if not port:
        return "Give the serial port (e.g. COM3 or /dev/ttyUSB0). Use serial_list to see them."
    try:
        with serial.Serial(port, baud or 9600, timeout=timeout or 2) as s:
            if action == "serial_send":
                s.write(data.encode().decode("unicode_escape").encode() if data else b"")
                return f"Sent {len(data)} chars to {port}."
            return s.read_until(b"\n").decode(errors="replace") or "(nothing received)"
    except Exception as e:
        return f"Serial error on {port}: {e}"


def devices(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "")).lower().strip()
    addr = str(parameters.get("address", "") or "").strip()
    name = str(parameters.get("name", "") or "").strip()
    if player:
        player.write_log(f"[devices] {a} {addr or name}")

    if a.startswith("bt_") or a.startswith("bluetooth_"):
        return _bt(a.split("_", 1)[1], addr, name)
    if a in ("scan", "paired", "connect", "disconnect", "pair", "trust", "power_on", "power_off"):
        return _bt(a, addr, name)
    if a in ("usb_list", "usb"):
        return _usb()
    if a.startswith("serial"):
        return _serial(a, str(parameters.get("port", "")), int(parameters.get("baud", 9600) or 9600),
                       str(parameters.get("data", "")), float(parameters.get("timeout", 2) or 2))
    if a == "ble_scan":
        try:
            import asyncio
            from bleak import BleakScanner
            found = asyncio.run(BleakScanner.discover(timeout=8.0, return_adv=True))
            rows = [f"{d.address}  {adv.rssi:>4} dBm  {d.name or adv.local_name or '(unnamed)'}"
                    for d, adv in found.values()]
            return "\n".join(sorted(rows)) or "No Bluetooth LE devices found nearby."
        except ImportError:
            return "Bluetooth LE scanning needs: pip install bleak"
        except Exception as e:
            return f"Bluetooth LE scan failed: {e}. Is Bluetooth switched on?"
    if a == "adb_devices":
        return _run(["adb", "devices", "-l"])
    return "Unknown action. Use: scan | ble_scan | paired | connect | disconnect | pair | power_on | power_off | usb_list | serial_list | serial_send | serial_read | adb_devices"


TOOL = {
    "name": "devices",
    "description": (
        "Controls hardware attached by Bluetooth or cable: scan/pair/connect/disconnect "
        "Bluetooth devices, switch Bluetooth power, list USB devices, list serial ports and "
        "send/read serial data (Arduino, microcontrollers), and list Android phones over ADB."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description":
                       "scan | ble_scan | paired | connect | disconnect | pair | power_on | power_off | usb_list | serial_list | serial_send | serial_read | adb_devices"},
            "name":    {"type": "STRING", "description": "Friendly device name, e.g. 'JBL Flip'"},
            "address": {"type": "STRING", "description": "Bluetooth MAC address AA:BB:CC:DD:EE:FF"},
            "port":    {"type": "STRING", "description": "Serial port e.g. COM3 or /dev/ttyUSB0"},
            "baud":    {"type": "INTEGER", "description": "Serial baud rate (default 9600)"},
            "data":    {"type": "STRING", "description": "Text to send over serial"},
        },
        "required": ["action"],
    },
    "handler": devices,
}

"""Double-click to start Mark-LV (needs Python 3.11+ installed: python.org)."""
import os
import subprocess
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
code = subprocess.call([sys.executable, "main.py"])
if code:
    print("\nMark-LV stopped with an error (code %s). The message is above;" % code)
    print("details are also in logs\\crash.log if that file exists.")
    input("Press Enter to close...")

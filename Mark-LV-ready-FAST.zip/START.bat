@echo off
cd /d "%~dp0"
where python >nul 2>nul && (python main.py) || (py main.py)
if errorlevel 1 (
    echo.
    echo Mark-LV stopped with an error (shown above). If logs\crash.log exists, that has more detail.
    pause
)

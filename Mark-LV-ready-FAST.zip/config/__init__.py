# config/__init__.py
import json, os, platform
from pathlib import Path

_CONFIG_PATH = Path(__file__).parent / "api_keys.json"

def _platform_os() -> str:
    """Auto-detect OS when config file is absent."""
    return {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}.get(
        platform.system(), "linux"
    )

def get_config() -> dict:
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def get_os() -> str:
    """Returns: 'windows' | 'mac' | 'linux'"""
    return get_config().get("os_system", _platform_os()).lower()

def is_windows() -> bool: return get_os() == "windows"
def is_mac()     -> bool: return get_os() == "mac"
def is_linux()   -> bool: return get_os() == "linux"


def unrestricted() -> bool:
    """User-controlled switch (config/api_keys.json -> "unrestricted_mode").

    When true the app's OWN guards step aside: no confirmation banners, file
    operations anywhere on disk (not just under the home folder), the
    pyautogui mouse-corner failsafe is off. Undo/Trash stay on because they
    never block anything. Defaults to True."""
    return bool(get_config().get("unrestricted_mode", True))

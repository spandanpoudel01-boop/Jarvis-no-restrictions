"""
link_agent.py — Mark-LV Link: lets the assistant control THIS device, but only
after you say yes.

Run it on the other computer (needs only Python 3; Pillow/pyautogui/tkinter are
optional extras for screenshots / keyboard-mouse / pop-up windows):

    python link_agent.py                      # message, open link, lock, info, screenshot
    python link_agent.py --allow-input        # also allow typing / key presses / clicks

How it works
  1. The assistant sends a pairing REQUEST to this device.
  2. A window (or a console question) shows who is asking and what they want.
     Nothing happens unless you press Yes.
  3. If you accept, the assistant gets a key that only works for the permissions
     you granted. Every command it runs is printed here.
  4. Closing this program (or Ctrl+C) ends all access immediately. Nothing is
     saved to disk and nothing starts automatically.

Only devices on a private (home / school) network can talk to it.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import io
import ipaddress
import json
import os
import platform
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser

PORT = 47474
BASE_PERMS = {"message", "open_url", "lock", "info", "screenshot"}
INPUT_PERMS = {"input"}

_paired: dict[str, dict] = {}          # token -> {"from", "granted", "at"}
_seen: dict[str, float] = {}           # replay protection
_lock = threading.Lock()
_ALLOWED: set[str] = set(BASE_PERMS)


def log(msg: str) -> None:
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


# ── asking the owner ─────────────────────────────────────────────────────────
def ask_owner(title: str, text: str) -> bool:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        ans = messagebox.askyesno(title, text, parent=root)
        root.destroy()
        return bool(ans)
    except Exception:
        pass
    try:
        return input(f"\n{title}\n{text}\nAllow? [y/N]: ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def show_message(text: str) -> None:
    try:
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, "Message from your assistant", 0x40 | 0x40000)
            return
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw(); r.attributes("-topmost", True)
        messagebox.showinfo("Message from your assistant", text, parent=r)
        r.destroy()
    except Exception:
        log(f"MESSAGE: {text}")


# ── commands ─────────────────────────────────────────────────────────────────
def do_command(cmd: str, value: str, extra: dict) -> dict:
    if cmd == "message":
        threading.Thread(target=show_message, args=(value[:500],), daemon=True).start()
        return {"ok": True, "result": "Message shown."}
    if cmd == "open_url":
        if not value.lower().startswith(("http://", "https://")):
            return {"ok": False, "result": "Only http/https links are allowed."}
        webbrowser.open(value)
        return {"ok": True, "result": "Link opened."}
    if cmd == "lock":
        if sys.platform == "win32":
            subprocess.Popen(["rundll32.exe", "user32.dll,LockWorkStation"])
        elif sys.platform == "darwin":
            subprocess.Popen(["pmset", "displaysleepnow"])
        else:
            subprocess.Popen(["loginctl", "lock-session"])
        return {"ok": True, "result": "Screen locked."}
    if cmd == "info":
        info = f"{socket.gethostname()} — {platform.platform()}"
        try:
            import psutil
            b = psutil.sensors_battery()
            if b:
                info += f", battery {int(b.percent)}%"
        except Exception:
            pass
        return {"ok": True, "result": info}
    if cmd == "screenshot":
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab()
            img.thumbnail((1280, 1280))
            buf = io.BytesIO(); img.save(buf, "PNG")
            return {"ok": True, "result": "Screenshot taken.",
                    "data_b64": base64.b64encode(buf.getvalue()).decode()}
        except Exception as e:
            return {"ok": False, "result": f"Screenshot unavailable ({e}). Install Pillow."}
    if cmd in ("type_text", "key", "click"):
        try:
            import pyautogui
            if cmd == "type_text":
                pyautogui.write(value[:500], interval=0.02)
            elif cmd == "key":
                pyautogui.hotkey(*[k.strip() for k in value.split("+")][:4])
            else:
                x, y = (int(v) for v in value.replace(",", " ").split()[:2])
                pyautogui.click(x, y)
            return {"ok": True, "result": f"{cmd} done."}
        except Exception as e:
            return {"ok": False, "result": f"Input failed ({e}). pip install pyautogui"}
    return {"ok": False, "result": f"Unknown command '{cmd}'."}


CMD_PERM = {"message": "message", "open_url": "open_url", "lock": "lock", "info": "info",
            "screenshot": "screenshot", "type_text": "input", "key": "input", "click": "input"}


# ── protocol ─────────────────────────────────────────────────────────────────
def sign(token: str, ts: str, cmd: str, value: str) -> str:
    return hmac.new(token.encode(), f"{ts}|{cmd}|{value}".encode(), hashlib.sha256).hexdigest()


def handle(req: dict, peer: str) -> dict:
    t = req.get("type")
    if t == "hello":
        return {"type": "hello", "agent": "mark-lv-link", "host": socket.gethostname()}

    if t == "pair_request":
        who = str(req.get("from", "unknown"))[:60]
        want = [w for w in req.get("want", []) if w in _ALLOWED | INPUT_PERMS]
        granted = [w for w in want if w in _ALLOWED]
        text = (f"'{who}' ({peer}) wants to connect to this device.\n\n"
                f"It will be allowed to: {', '.join(granted) or 'nothing'}.\n"
                f"You will see every action it takes, and closing this program ends it.\n\n"
                f"Allow?")
        log(f"Pairing request from {who} ({peer}) for {granted}")
        if not granted or not ask_owner("Connection request", text):
            log("Request declined.")
            return {"type": "pair_denied"}
        token = secrets.token_hex(16)
        with _lock:
            _paired[token] = {"from": who, "granted": set(granted), "at": time.time()}
        log(f"Accepted. {who} may: {', '.join(granted)}")
        return {"type": "pair_accept", "token": token, "granted": granted,
                "host": socket.gethostname()}

    if t == "cmd":
        token = str(req.get("token", ""))
        with _lock:
            entry = _paired.get(token)
        if not entry:
            return {"ok": False, "result": "Not paired."}
        ts, cmd, value = str(req.get("ts", "")), str(req.get("cmd", "")), str(req.get("value", ""))
        sig = str(req.get("sig", ""))
        try:
            fresh = abs(time.time() - float(ts)) < 30
        except ValueError:
            fresh = False
        if not (fresh and hmac.compare_digest(sig, sign(token, ts, cmd, value))):
            return {"ok": False, "result": "Bad or expired signature."}
        now = time.time()
        with _lock:
            for k in [k for k, v in _seen.items() if now - v > 60]:
                _seen.pop(k, None)
            if sig in _seen:
                return {"ok": False, "result": "Replay rejected."}
            _seen[sig] = now
        perm = CMD_PERM.get(cmd)
        if cmd == "unpair":
            with _lock:
                _paired.pop(token, None)
            log(f"{entry['from']} disconnected.")
            return {"ok": True, "result": "Disconnected."}
        if perm is None or perm not in entry["granted"]:
            log(f"BLOCKED {cmd} from {entry['from']} (not granted)")
            return {"ok": False, "result": f"'{cmd}' was not allowed on this device."}
        log(f"{entry['from']} -> {cmd} {value[:60]}")
        return do_command(cmd, value, req)
    return {"ok": False, "result": "Unknown request."}


def serve_client(conn: socket.socket, addr) -> None:
    peer = addr[0]
    try:
        if not ipaddress.ip_address(peer).is_private and not ipaddress.ip_address(peer).is_loopback:
            conn.close(); return
        conn.settimeout(120)
        data = b""
        while not data.endswith(b"\n") and len(data) < 65536:
            chunk = conn.recv(4096)
            if not chunk:
                break
            data += chunk
        resp = handle(json.loads(data.decode()), peer)
        conn.sendall((json.dumps(resp) + "\n").encode())
    except Exception as e:
        log(f"error from {peer}: {e}")
    finally:
        try:
            conn.close()
        except Exception:
            pass


def main() -> None:
    ap = argparse.ArgumentParser(description="Mark-LV Link agent")
    ap.add_argument("--allow-input", action="store_true",
                    help="also allow typing, key presses and clicks")
    ap.add_argument("--port", type=int, default=PORT)
    a = ap.parse_args()
    if a.allow_input:
        _ALLOWED.update(INPUT_PERMS)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", a.port))
    srv.listen(5)
    log(f"Mark-LV Link running on port {a.port} as '{socket.gethostname()}'.")
    log(f"Allowed: {', '.join(sorted(_ALLOWED))}.  Nothing connects unless you press Yes.  Ctrl+C to stop.")
    try:
        while True:
            conn, addr = srv.accept()
            threading.Thread(target=serve_client, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        log("Stopped. All access ended.")


if __name__ == "__main__":
    main()

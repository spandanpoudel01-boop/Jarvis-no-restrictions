"""
core/crashlog.py — turn crashes into a readable log instead of a silent exit.

PyQt6 aborts the whole process when a Python exception escapes a Qt callback
(paint events, timers, slots). Installing our own excepthook makes PyQt keep
running and hands us the traceback, which is written to logs/crash.log. Hard
crashes (segfaults) are captured by faulthandler into logs/fault.log.

If the app ever misbehaves, ask it to run self_dev diagnose — it reads this log —
or send logs/crash.log and logs/fault.log.
"""
from __future__ import annotations

import faulthandler
import sys
import threading
import time
import traceback
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
_fault_file = None


def _write(text: str) -> None:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        log = LOG_DIR / "crash.log"
        if log.exists() and log.stat().st_size > 512_000:     # keep it small
            log.replace(LOG_DIR / "crash.old.log")
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n{text}\n")
    except Exception:
        pass


def install() -> None:
    global _fault_file
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        _fault_file = open(LOG_DIR / "fault.log", "a")
        faulthandler.enable(file=_fault_file, all_threads=True)
    except Exception:
        pass

    def hook(exc_type, exc, tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc, tb)
            return
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        print(text, file=sys.stderr)
        _write(text)

    def thread_hook(args):
        hook(args.exc_type, args.exc_value, args.exc_traceback)

    sys.excepthook = hook
    threading.excepthook = thread_hook


def tail(lines: int = 25) -> str:
    """Last lines of the crash log, for the diagnose tool."""
    try:
        txt = (LOG_DIR / "crash.log").read_text(encoding="utf-8", errors="replace")
        return "\n".join(txt.splitlines()[-lines:])
    except Exception:
        return ""

"""
core/mini_orb.py — the small floating icon shown while the main window is
minimized, plus a system-tray entry.

* A frameless, always-on-top, draggable orb that pulses with the assistant's
  state (listening / thinking / speaking).
* The last thing the assistant said floats beside it as a short guidance bubble,
  so it can keep walking you through a task while the HUD is out of the way.
* Click the orb (or the tray icon) to restore the full window. Right-click for
  a small menu (Open, Quit).

It owns no assistant logic: MainWindow feeds it state and text.
"""
from __future__ import annotations

import math
from pathlib import Path

from PyQt6.QtCore import QPoint, QRectF, Qt, QTimer
from PyQt6.QtGui import (
    QAction, QBrush, QColor, QFont, QIcon, QPainter, QPen, QPixmap,
    QRadialGradient,
)
from PyQt6.QtWidgets import QApplication, QMenu, QSystemTrayIcon, QWidget

_SIZE = 64
_BUBBLE_MAX = 220
_STATE_COLOR = {
    "LISTENING": "#35d0ff",
    "THINKING":  "#ffb84d",
    "PROCESSING": "#ffb84d",
    "SPEAKING":  "#6dff9c",
    "SLEEPING":  "#6b7a8c",
}


def _orb_pixmap(color: QColor, size: int = 64) -> QPixmap:
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QRadialGradient(size / 2, size / 2, size / 2)
    g.setColorAt(0.0, color.lighter(170))
    g.setColorAt(0.55, color)
    g.setColorAt(1.0, QColor(color.red(), color.green(), color.blue(), 0))
    p.setBrush(QBrush(g))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawEllipse(2, 2, size - 4, size - 4)
    p.end()
    return pm


class MiniOrb(QWidget):
    def __init__(self, main_window, name: str = "JARVIS"):
        super().__init__(None)
        self._main = main_window
        self._name = name
        self._state = "LISTENING"
        self._bubble = ""
        self._phase = 0.0
        self._drag: QPoint | None = None
        self._moved = False

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint
                            | Qt.WindowType.WindowStaysOnTopHint
                            | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(_SIZE + _BUBBLE_MAX + 12, _SIZE + 8)
        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.right() - self.width() - 24, screen.bottom() - self.height() - 48)

        self._tick = QTimer(self)
        self._tick.timeout.connect(self._animate)
        self._fade = QTimer(self)
        self._fade.setSingleShot(True)
        self._fade.timeout.connect(self._clear_bubble)

        # System tray: always reachable even if the orb is dragged off-screen.
        _logo = Path(__file__).resolve().parent.parent / "assets" / "logo.png"
        _ic = QIcon(str(_logo)) if _logo.exists() else QIcon(_orb_pixmap(QColor("#35d0ff")))
        self._tray = QSystemTrayIcon(_ic, self)
        self._tray.setToolTip(name)
        menu = QMenu()
        act_open = QAction("Open", menu)
        act_open.triggered.connect(self.restore_main)
        act_quit = QAction("Quit", menu)
        act_quit.triggered.connect(QApplication.quit)
        menu.addAction(act_open)
        menu.addAction(act_quit)
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda r: self.restore_main()
            if r == QSystemTrayIcon.ActivationReason.Trigger else None)
        self._menu = menu
        if QSystemTrayIcon.isSystemTrayAvailable():
            self._tray.show()

    # -- API used by MainWindow ------------------------------------------------
    def set_state(self, state: str) -> None:
        self._state = (state or "").upper()
        self.update()

    def say(self, text: str) -> None:
        text = " ".join((text or "").split())
        if not text:
            return
        self._bubble = text if len(text) <= 140 else text[:137] + "…"
        self._fade.start(9000)
        self.update()

    def minimized(self) -> None:
        self.show()
        self._tick.start(40)

    def restored(self) -> None:
        self._tick.stop()
        self.hide()

    def restore_main(self) -> None:
        self._main.showNormal()
        self._main.raise_()
        self._main.activateWindow()

    # -- internals -------------------------------------------------------------
    def _color(self) -> QColor:
        return QColor(_STATE_COLOR.get(self._state, "#35d0ff"))

    def _clear_bubble(self) -> None:
        self._bubble = ""
        self.update()

    def _animate(self) -> None:
        self._phase += 0.12 if self._state in ("SPEAKING", "THINKING", "PROCESSING") else 0.05
        self.update()

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        pulse = 1.0 + 0.08 * math.sin(self._phase)
        d = (_SIZE - 8) * pulse
        cx, cy = self.width() - _SIZE / 2 - 2, self.height() / 2
        c = self._color()
        g = QRadialGradient(cx, cy, d / 2)
        g.setColorAt(0.0, c.lighter(170))
        g.setColorAt(0.6, c)
        g.setColorAt(1.0, QColor(c.red(), c.green(), c.blue(), 40))
        p.setBrush(QBrush(g))
        p.setPen(QPen(c.lighter(140), 1.5))
        p.drawEllipse(QRectF(cx - d / 2, cy - d / 2, d, d))
        if self._bubble:
            f = QFont(); f.setPointSize(9)
            p.setFont(f)
            rect = QRectF(4, 4, _BUBBLE_MAX, self.height() - 8)
            p.setBrush(QColor(12, 18, 28, 225))
            p.setPen(QPen(c, 1))
            p.drawRoundedRect(rect, 10, 10)
            p.setPen(QColor("#e8f4ff"))
            p.drawText(rect.adjusted(8, 4, -8, -4),
                       int(Qt.AlignmentFlag.AlignVCenter.value) | int(Qt.TextFlag.TextWordWrap.value),
                       self._bubble)

    def mousePressEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._moved = False
        elif e.button() == Qt.MouseButton.RightButton:
            self._menu.exec(e.globalPosition().toPoint())

    def mouseMoveEvent(self, e) -> None:
        if self._drag is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self._moved = True
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton and not self._moved:
            self.restore_main()
        self._drag = None

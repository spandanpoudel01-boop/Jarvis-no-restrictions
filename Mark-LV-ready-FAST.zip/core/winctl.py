"""
core/winctl.py — window control that VERIFIES what it did.

The failure this exists to prevent: an app is "focused" by a command that never
checks the result, and then text is typed into whatever window happens to be in
front (for example the browser tab the user was chatting in). Here a window only
counts as focused after we have read back which window is actually in front, and
callers refuse to type when it is not the one they asked for.

Windows uses ctypes directly (no extra packages). Linux uses wmctrl/xdotool and
macOS uses osascript.
"""
from __future__ import annotations

import subprocess
import sys
import time

_WIN = sys.platform == "win32"
_MAC = sys.platform == "darwin"
_NOWIN = 0x08000000 if _WIN else 0


def _run(cmd: list[str], timeout: int = 5) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           creationflags=_NOWIN)
        return (r.stdout or "").strip()
    except Exception:
        return ""


# ── Windows (ctypes) ─────────────────────────────────────────────────────────
if _WIN:
    import ctypes
    from ctypes import wintypes

    _u32 = ctypes.windll.user32
    _k32 = ctypes.windll.kernel32

    def _title(hwnd) -> str:
        n = _u32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(n + 1)
        _u32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value

    def _windows() -> list[tuple[int, str]]:
        out: list[tuple[int, str]] = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _):
            if _u32.IsWindowVisible(hwnd):
                t = _title(hwnd)
                if t:
                    out.append((hwnd, t))
            return True

        _u32.EnumWindows(proto(cb), 0)
        return out

    def _force_front(hwnd) -> None:
        if _u32.IsIconic(hwnd):
            _u32.ShowWindow(hwnd, 9)                 # SW_RESTORE
        _u32.keybd_event(0x12, 0, 0, 0)              # tap ALT: lifts the foreground lock
        _u32.keybd_event(0x12, 0, 2, 0)
        fg = _u32.GetForegroundWindow()
        t_fg = _u32.GetWindowThreadProcessId(fg, None)
        t_me = _k32.GetCurrentThreadId()
        if t_fg and t_fg != t_me:
            _u32.AttachThreadInput(t_me, t_fg, True)
        _u32.SetForegroundWindow(hwnd)
        _u32.BringWindowToTop(hwnd)
        if t_fg and t_fg != t_me:
            _u32.AttachThreadInput(t_me, t_fg, False)

    def active_title() -> str:
        return _title(_u32.GetForegroundWindow())

    def list_windows() -> list[str]:
        return [t for _, t in _windows()]

    def _focus_once(sub: str) -> None:
        cands = [(h, t) for h, t in _windows() if sub.lower() in t.lower()]
        if not cands:
            return
        cands.sort(key=lambda x: len(x[1]))          # the most specific (shortest) match
        _force_front(cands[0][0])

# ── macOS ────────────────────────────────────────────────────────────────────
elif _MAC:
    def active_title() -> str:
        return _run(["osascript", "-e",
                     'tell application "System Events" to get name of first application '
                     'process whose frontmost is true'])

    def list_windows() -> list[str]:
        out = _run(["osascript", "-e",
                    'tell application "System Events" to get name of every application '
                    'process whose background only is false'])
        return [x.strip() for x in out.split(",") if x.strip()]

    def _focus_once(sub: str) -> None:
        _run(["osascript", "-e", f'tell application "{sub}" to activate'])

# ── Linux ────────────────────────────────────────────────────────────────────
else:
    def active_title() -> str:
        return _run(["xdotool", "getactivewindow", "getwindowname"])

    def list_windows() -> list[str]:
        out = _run(["wmctrl", "-l"])
        return [l.split(None, 3)[3] for l in out.splitlines() if len(l.split(None, 3)) == 4]

    def _focus_once(sub: str) -> None:
        if _run(["wmctrl", "-a", sub]) == "":
            _run(["xdotool", "search", "--name", sub, "windowactivate"])


def is_front(sub: str) -> bool:
    return sub.lower() in active_title().lower()


def wait_for_window(sub: str, timeout: float = 10.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if any(sub.lower() in t.lower() for t in list_windows()):
            return True
        time.sleep(0.25)
    return False


def focus_verified(sub: str, attempts: int = 4) -> tuple[bool, str]:
    """Bring a window to the front and CONFIRM it is there.

    Returns (ok, title_of_front_window). ok is True only if the front window's
    title really contains `sub` after the attempt."""
    sub = (sub or "").strip()
    if not sub:
        return False, active_title()
    for i in range(attempts):
        if is_front(sub):
            time.sleep(0.15)                          # let it settle, then re-check
            if is_front(sub):
                return True, active_title()
        _focus_once(sub)
        time.sleep(0.35 + 0.15 * i)
    return is_front(sub), active_title()

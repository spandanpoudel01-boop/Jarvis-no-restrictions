"""
core/composite_voice.py — a voice core that does NOT use Gemini Live.

    microphone -> speech-to-text -> BRAIN (Venice first, Gemini as backup, with tools)
                                 -> text-to-speech -> speakers

Turn it on with  "core": "composite"  in config/api_keys.json (default "live" keeps
Gemini Live). If this core cannot start, main.py falls back to Gemini Live.

Config keys (all in config/api_keys.json):
  venice_api_key, gemini_api_key, openai_api_key (only for optional Whisper STT)
  brain_order        ["venice", "gemini"]            who answers first
  venice_chat_model  "venice-uncensored-1-2"         must support tool calls to run actions
  gemini_chat_model  "gemini-3.8-flash"
  stt_provider       "gemini" | "openai"             (openai = whisper-1, needs openai_api_key)
  gemini_stt_model   "gemini-3.8-flash"
  tts_provider       "gemini" | "venice"
  gemini_tts_model   "gemini-3.8-flash-tts"
  venice_tts_model   "tts-kokoro",  venice_tts_voice "af_heart"

If the Venice model rejects tool calls, the turn goes to Gemini so actions still run:
the assistant never says "done" for something it had no tool to do.

Half duplex: the microphone is ignored while it speaks (and briefly after), so it never
answers itself. Press the stop button to cut it off mid-sentence.
"""
from __future__ import annotations

import asyncio
import io
import json
import re
import threading
import time
import traceback
import wave
from types import SimpleNamespace

import base64
import random
import numpy as np
import requests
from requests.adapters import HTTPAdapter

_VENICE = "https://api.venice.ai/api/v1"
_NOISE_TEXT = re.compile(r"^\W*(\[?(silence|noise|inaudible|no speech|music)[^\]]*\]?)?\W*$", re.I)
_MAX_TOOL_ROUNDS = 8
_XAI = "https://api.x.ai/v1"
_HIST_N = 10                       # turns of history sent to the model (less to send = faster)

# One shared HTTP session: keeps the TLS connection open between calls instead of
# paying a fresh handshake for every model call and every spoken sentence.
_SESSION = requests.Session()
_SESSION.mount("https://", HTTPAdapter(pool_connections=4, pool_maxsize=8))


class _NoTools(Exception):
    """The chosen model cannot call tools."""


_CFG_CACHE = ({}, 0.0)


def _cfg() -> dict:
    """Config, re-read from disk at most every 2 s (it used to be read on every call)."""
    global _CFG_CACHE
    data, ts = _CFG_CACHE
    if data and time.monotonic() - ts < 2.0:
        return data
    try:
        from config import get_config
        data = get_config() or {}
    except Exception:
        data = {}
    _CFG_CACHE = (data, time.monotonic())
    return data


def _plain(d):
    """Declaration -> plain dict with only name/description/parameters."""
    if not isinstance(d, dict):
        try:
            d = d.model_dump(exclude_none=True)
        except Exception:
            d = {"name": getattr(d, "name", ""), "description": getattr(d, "description", "")}
    out = {"name": d.get("name", ""), "description": d.get("description", "")}
    if d.get("parameters"):
        out["parameters"] = d["parameters"]
    return out


def _lower_types(s):
    if isinstance(s, dict):
        r = {}
        for k, v in s.items():
            if k == "type" and isinstance(v, str):
                r[k] = v.lower()
            elif k in ("properties",) and isinstance(v, dict):
                r[k] = {pk: _lower_types(pv) for pk, pv in v.items()}
            else:
                r[k] = _lower_types(v)
        return r
    if isinstance(s, list):
        return [_lower_types(x) for x in s]
    return s


def _shorten(s, n=70):
    """Trim every description inside a parameter schema (fewer tokens = faster first word)."""
    if isinstance(s, dict):
        return {k: (v[:n] if k == "description" and isinstance(v, str) else _shorten(v, n))
                for k, v in s.items()}
    if isinstance(s, list):
        return [_shorten(x, n) for x in s]
    return s


def _openai_tools(decls: list[dict]) -> list[dict]:
    tools = []
    for d in decls:
        params = _shorten(_lower_types(d.get("parameters") or {"type": "object", "properties": {}}))
        if params.get("type") != "object":
            params = {"type": "object", "properties": {}}
        params.setdefault("properties", {})
        tools.append({"type": "function", "function": {
            "name": d["name"], "description": (d.get("description") or "")[:160],
            "parameters": params}})
    return tools


_LEAD = r"(?:(?:hey|ok|okay|please|jarvis|can you|could you|would you|will you|i want you to|i need you to|go ahead and|now|and|then)\b[\s,]*)*"
_VERBS = (r"open|close|launch|start|run|play|pause|resume|stop|skip|search|google|look up|find|send|text|message|"
          r"call|dial|email|set|turn|switch|mute|unmute|volume|increase|decrease|lower|raise|take|capture|"
          r"screenshot|type|click|press|scroll|minimi[sz]e|maximi[sz]e|shut ?down|restart|reboot|lock|"
          r"remind|create|delete|remove|move|copy|rename|save|download|install|uninstall")
_ACTION_RE = re.compile(rf"^\W*{_LEAD}(?:{_VERBS})\b|\b(?:my|the) (?:screen|camera|webcam)\b|\bscreenshot\b", re.I)


def _wav(pcm: bytes, rate: int) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()


def _to_24k_pcm(wav_bytes: bytes) -> bytes:
    with wave.open(io.BytesIO(wav_bytes)) as w:
        rate, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    if sw != 2:
        raise RuntimeError("unsupported wav sample width")
    a = np.frombuffer(raw, dtype=np.int16)
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1).astype(np.int16)
    if rate != 24000 and a.size:
        n = int(a.size * 24000 / rate)
        a = np.interp(np.linspace(0, a.size - 1, n), np.arange(a.size), a).astype(np.int16)
    return a.tobytes()


def _sentences(text: str) -> list[str]:
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+|\n+", text) if p.strip()]
    out, buf = [], ""
    for p in parts:                       # merge tiny pieces so TTS calls stay worthwhile
        buf = f"{buf} {p}".strip()
        if len(buf) >= 28:
            out.append(buf)
            buf = ""
    if buf:
        if out and len(buf) < 12:
            out[-1] += " " + buf
        else:
            out.append(buf)
    return out


class _Splitter:
    """Turns streamed text into speakable chunks as it arrives.

    The first chunk is allowed to be short so speech starts as early as possible;
    later chunks are a little longer so each TTS call is worthwhile. Code blocks are
    never read aloud."""
    _END = re.compile(r"(?<=[.!?\u2026])\s+|\n+")

    def __init__(self):
        self.buf = ""          # incomplete tail of the stream
        self.pend = ""         # complete sentences waiting to reach the minimum length
        self.sent_any = False
        self.fence = False     # inside a ``` block

    def _min(self) -> int:
        return 28 if self.sent_any else 12

    def _strip_fence(self, piece: str) -> str:
        if "```" not in piece and not self.fence:
            return piece
        keep = []
        for i, seg in enumerate(piece.split("```")):
            if i > 0:
                self.fence = not self.fence
                if self.fence:
                    keep.append("The code is on the screen.")
            if not self.fence and seg.strip():
                keep.append(seg)
        return " ".join(keep)

    def _take(self, pieces) -> list[str]:
        out = []
        for p in pieces:
            p = self._strip_fence(p).strip()
            if not p:
                continue
            self.pend = f"{self.pend} {p}".strip()
            if len(self.pend) >= self._min():
                out.append(self.pend)
                self.pend = ""
                self.sent_any = True
        return out

    def feed(self, delta: str) -> list[str]:
        self.buf += delta
        pieces = self._END.split(self.buf)
        self.buf = pieces.pop()
        if len(self.buf) > 140 and not self.fence:        # long run-on: cut at a comma
            m = max(self.buf.rfind(", "), self.buf.rfind("; "), self.buf.rfind(" \u2014 "))
            if m > 40:
                pieces.append(self.buf[:m + 1])
                self.buf = self.buf[m + 1:]
        return self._take(pieces)

    def flush(self) -> list[str]:
        rest = self._take([self.buf]) if self.buf.strip() else []
        self.buf = ""
        tail = self.pend.strip()
        self.pend = ""
        if tail:
            rest.append(tail)
        return rest


def _clean_for_speech(t: str) -> str:
    t = re.sub(r"```.*?```", " (code shown on screen) ", t, flags=re.S)
    t = re.sub(r"[*_`#>]+", "", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t)
    t = re.sub(r"[\U0001F300-\U0001FAFF☀-➿]", "", t)
    return re.sub(r"[ \t]+", " ", t).strip()


def build(Base, ns: dict):
    """Return the composite class, derived from main.JarvisLive. `ns` = main's globals()."""

    SEND_SR = ns["SEND_SAMPLE_RATE"]
    sd = ns["sd"]
    types = ns["types"]
    genai = ns["genai"]

    class CompositeLive(Base):
        def __init__(self, ui):
            super().__init__(ui)
            self._hist: list[tuple[str, str]] = []       # (role, text) across turns
            self._submit_q: asyncio.Queue | None = None
            self._ppt_buf: list[np.ndarray] = []
            self._mic_restart = False
            self._sys_cache = ("", 0.0)
            self._decls: list[dict] = []
            self._venice_tools_ok = True
            self._announced: set[str] = set()
            self._gclient = None
            self._venice_skip_until = 0.0   # Venice was too slow: Gemini answers until this time
            self._tools_ran = 0
            self._ack_pcm = []
            self._tools_cache = (0, [])
            self._conv_id = __import__('uuid').uuid4().hex
            self._grok_effort_ok = True     # reasoning_effort accepted by the chosen Grok model?
            self._think_off = True        # ask Gemini to skip 'thinking' (faster); auto-disabled if refused

        # ── small helpers ────────────────────────────────────────────────────
        def _note(self, key: str, msg: str) -> None:
            if key not in self._announced:
                self._announced.add(key)
                try:
                    self.ui.write_log(f"SYS: {msg}")
                except Exception:
                    pass

        def _gem(self):
            if self._gclient is None:
                self._gclient = genai.Client(api_key=ns["_get_api_key"]())
            return self._gclient

        def _keys(self) -> dict:
            c = _cfg()
            return {"venice": str(c.get("venice_api_key", "") or ""),
                    "gemini": str(c.get("gemini_api_key", "") or "") or ns["_get_api_key"](),
                    "openai": str(c.get("openai_api_key", "") or ""),
                    "xai": str(c.get("xai_api_key", "") or "")}

        def _safety_net(self) -> bool:
            """Gemini may still help where Grok cannot (hearing errors, PDF/audio/video files)."""
            return bool(_cfg().get("gemini_safety_net", True)) and bool(self._keys()["gemini"])

        def _system_prompt(self) -> str:
            text, ts = self._sys_cache
            if text and time.monotonic() - ts < 60:
                return text
            cfg = self._build_config()
            si = cfg.system_instruction
            if not isinstance(si, str):
                try:
                    si = "\n".join(p.text for p in si.parts if getattr(p, "text", None))
                except Exception:
                    si = str(si)
            si += (
                "\n\n[VOICE CORE]\nYour words are spoken aloud by a text-to-speech voice. Reply in short, "
                "natural sentences. No markdown, no lists, no emoji, no code read aloud (code goes in a "
                "file or on screen via a tool). Act through your tools; say an action is done only if the "
                "tool result says so. To see the screen call screen_process.\n"
            )
            self._sys_cache = (si, time.monotonic())
            if not self._decls:
                raw = (ns["TOOL_DECLARATIONS"]
                       + self._action_registry.get_tool_declarations()
                       + self._plugin_registry.get_tool_declarations())
                self._decls = [_plain(d) for d in raw if (d if isinstance(d, dict) else _plain(d)).get("name")]
            return si

        # ── overrides of the Gemini-Live-only entry points ───────────────────
        def _submit(self, text: str, *, system: bool = False) -> None:
            if not self._loop or self._submit_q is None:
                return
            self._loop.call_soon_threadsafe(self._submit_q.put_nowait, (text, system))

        def speak(self, text: str):
            self._submit(f"[system note — say this to the user in your own words] {text}", system=True)

        def plugin_say(self, instruction: str) -> None:
            self._submit(f"[system note — say this to the user in your own words] {instruction}",
                         system=True)

        def _on_text_command(self, text: str):
            if self._wake_enabled and not self._awake:
                self.ui.write_log("SYS: I'm asleep — say 'Hey Jarvis' or tap WAKE NOW first.")
                return
            self._submit(text)

        def _on_voice_change(self):                # voice is read on every TTS call
            self._sys_cache = ("", 0.0)

        def _on_audio_device_change(self):
            self._mic_restart = True

        def request_reconnect(self, keep_context: bool = True, reason: str = ""):
            self._sys_cache = ("", 0.0)

        def interrupt(self) -> None:
            self._interrupted = True
            super().interrupt()

        # ── microphone with energy VAD ───────────────────────────────────────
        async def _mic_task(self):
            loop = asyncio.get_event_loop()
            blk = 512
            try:
                _tt = _cfg().get("turn_tuning") or {}
                end_quiet = (float(_tt.get("silence_ms", 400)) / 1000.0) if _tt.get("enabled", True) else 0.5
            except Exception:
                end_quiet = 0.5
            end_quiet = min(1.0, max(0.25, end_quiet))      # was a fixed 0.5 s
            st = {"noise": 120.0, "voice": 0, "active": False, "buf": [], "quiet": 0.0,
                  "dur": 0.0, "pre": []}

            def end_utt():
                if st["dur"] >= 0.35 and st["buf"]:
                    pcm = np.concatenate(st["buf"]).astype(np.int16).tobytes()
                    loop.call_soon_threadsafe(self._utt_q.put_nowait, pcm)
                st.update(active=False, buf=[], quiet=0.0, dur=0.0, voice=0)

            def cb(indata, frames, ti, status):
                if self._wake_enabled and not self._awake:
                    det = self._wake_detector
                    if det is not None:
                        det.feed(indata)
                    return
                with self._speaking_lock:
                    talking = self._is_speaking
                busy = talking or self._tail_active() or getattr(self, "_thinking", False)
                if busy or self.ui.muted or self._phone_active:
                    if st["active"]:
                        st.update(active=False, buf=[], quiet=0.0, dur=0.0, voice=0)
                    return
                a = indata.reshape(-1)
                rms = float(np.sqrt(np.mean(a.astype(np.float32) ** 2)))
                step = len(a) / SEND_SR
                try:
                    self.ui.set_audio_level(min(1.0, rms / 6000.0))
                except Exception:
                    pass
                if self._ptt_enabled:
                    if self._ptt_held:
                        st["active"] = True
                        st["buf"].append(a.copy())
                        st["dur"] += step
                    elif st["active"]:
                        end_utt()
                    return
                thr = max(450.0, st["noise"] * 3.0)
                loud = rms > thr
                if not st["active"]:
                    st["pre"].append(a.copy())
                    st["pre"] = st["pre"][-8:]
                    if loud:
                        st["voice"] += 1
                    else:
                        st["voice"] = 0
                        st["noise"] = 0.97 * st["noise"] + 0.03 * rms
                    if st["voice"] >= 3:
                        st["active"] = True
                        st["buf"] = list(st["pre"])
                        st["dur"] = sum(len(x) for x in st["buf"]) / SEND_SR
                        st["quiet"] = 0.0
                        try:
                            self._last_user_speech = time.monotonic()
                        except Exception:
                            pass
                    return
                st["buf"].append(a.copy())
                st["dur"] += step
                if loud:
                    st["quiet"] = 0.0
                    self._last_user_speech = time.monotonic()
                else:
                    st["quiet"] += step
                if st["quiet"] >= end_quiet or st["dur"] >= 30:
                    end_utt()

            def open_mic(dev):
                kw = dict(samplerate=SEND_SR, channels=1, dtype="int16", blocksize=blk,
                          device=dev, callback=cb)
                try:
                    return sd.InputStream(latency="low", **kw)
                except Exception:
                    return sd.InputStream(**kw)

            while True:
                name = ns["get_input_device"]()
                dev = ns["audio_devices"].resolve(name, "input")
                try:
                    stream = open_mic(dev)
                except Exception as e:
                    if dev is None:
                        raise
                    self.ui.write_log(f"SYS: Microphone '{name}' unavailable — using system default.")
                    stream = open_mic(None)
                self._mic_restart = False
                with stream:
                    print("[Composite] 🎤 mic open")
                    while not self._mic_restart:
                        await asyncio.sleep(0.2)

        # ── speech to text ───────────────────────────────────────────────────
        def _stt_sync(self, pcm: bytes) -> str:
            wav = _wav(pcm, SEND_SR)
            c = _cfg()
            prov = str(c.get("stt_provider", "gemini") or "gemini").lower()
            k = self._keys()
            if prov == "grok" and k["xai"]:
                err = ""
                try:
                    r = _SESSION.post(f"{_XAI}/stt", headers={"Authorization": f"Bearer {k['xai']}"},
                                      files={"file": ("a.wav", wav, "audio/wav")}, timeout=(5, 30))
                    if r.status_code == 200:
                        return (r.json().get("text") or "").strip()
                    err = f"{r.status_code}: {r.text[:120]}"
                except Exception as e:
                    err = str(e)
                print(f"[Composite] Grok hearing failed: {err}")
                if not self._safety_net():
                    raise RuntimeError(f"Grok could not transcribe ({err})")
                self._note("sg", f"Grok could not transcribe ({err[:80]}); Gemini is hearing this one.")
            if prov == "openai" and k["openai"]:
                r = _SESSION.post("https://api.openai.com/v1/audio/transcriptions",
                                  headers={"Authorization": f"Bearer {k['openai']}"},
                                  files={"file": ("a.wav", wav, "audio/wav")},
                                  data={"model": "whisper-1"}, timeout=40)
                if r.status_code == 200:
                    return (r.json().get("text") or "").strip()
                print(f"[Composite] whisper {r.status_code}: {r.text[:120]}")
            model = str(c.get("gemini_stt_model", "") or "gemini-3.8-flash")
            contents = [types.Part.from_bytes(data=wav, mime_type="audio/wav"),
                        "Transcribe this speech exactly, in the language spoken. Output only the "
                        "words, nothing else. If there is no clear human speech, output nothing."]
            for _ in range(2):
                kw = {"temperature": 0.0}
                if self._think_off:
                    kw["thinking_config"] = types.ThinkingConfig(thinking_budget=0)
                try:
                    resp = self._gem().models.generate_content(
                        model=model, contents=contents, config=types.GenerateContentConfig(**kw))
                    return (resp.text or "").strip()
                except Exception as e:
                    if self._think_off and re.search(r"think", str(e), re.I):
                        self._think_off = False         # this model refuses it: retry plain
                        continue
                    raise
            return ""

        # ── brains ───────────────────────────────────────────────────────────
        async def _run_tool(self, name: str, args: dict, call_id: str) -> str:
            self._tools_ran += 1
            fc = SimpleNamespace(id=call_id, name=name, args=args)
            fr = await self._execute_tool(fc)
            res = str((fr.response or {}).get("result", "Done."))
            if name == "screen_process" and self._pending_vision:
                img, mime, q, angle = self._pending_vision
                self._pending_vision = None
                try:
                    desc = await asyncio.to_thread(self._see, img, mime, q)
                    res = f"What the {angle} shows: {desc}"
                except Exception as e:
                    res = f"I captured the {angle} but could not analyse it: {e}"
                self._vision_busy = False
                if self._vision_cam_active:
                    try:
                        self.ui.stop_camera_stream()
                    except Exception:
                        pass
                    self._vision_cam_active = False
            return res

        def _venice_post(self, messages, tools):
            c = _cfg()
            body = {"model": str(c.get("venice_chat_model", "") or "venice-uncensored-1-2"),
                    "messages": messages,
                    "venice_parameters": {"include_venice_system_prompt": False}}
            if tools:
                body["tools"] = tools
                body["tool_choice"] = "auto"
            r = _SESSION.post(f"{_VENICE}/chat/completions",
                              headers={"Authorization": f"Bearer {self._keys()['venice']}",
                                       "Content-Type": "application/json"},
                              json=body, timeout=(5, self._venice_wait() * 2))
            if r.status_code != 200:
                msg = r.text[:300]
                if tools and r.status_code in (400, 422) and re.search(r"tool|function", msg, re.I):
                    raise _NoTools(msg)
                raise RuntimeError(f"Venice {r.status_code}: {msg}")
            return r.json()["choices"][0]["message"]

        def _gemini_in_order(self) -> bool:
            """True when a second brain (Grok or Gemini) is in brain_order, i.e. Venice may fall back."""
            o = [str(x).lower() for x in (_cfg().get("brain_order") or ["venice", "gemini"])]
            return "gemini" in o or "grok" in o

        def _venice_wait(self) -> float:
            """Seconds Venice may stay silent before we give up and let Gemini answer."""
            try:
                w = max(3.0, float(_cfg().get("venice_timeout", 7)))
            except Exception:
                w = 7.0
            return w if self._gemini_in_order() else max(w, 30.0)   # nothing to fall back to

        def _venice_slow(self, e: Exception) -> bool:
            if (isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectionError))
                    and self._gemini_in_order()):
                self._venice_skip_until = time.monotonic() + 300
                self._note("vs", f"Venice took longer than {self._venice_wait():.0f}s to answer, so Gemini "
                                 "answers for the next 5 minutes. (Set brain_order to [\"gemini\",\"venice\"] "
                                 "to always use Gemini first.)")
                return True
            return False

        def _oai_stream(self, label, url, key, body, on_text):
            """Read an OpenAI-style streamed chat reply (Venice, xAI/Grok, ...). Text goes to
            on_text as it arrives; returns {"content": str, "tool_calls": [...]}."""
            content, calls = [], {}
            with _SESSION.post(url, headers=self._oai_headers(label, key),
                               json=body, timeout=(5, self._wait_for(label)), stream=True) as r:
                if r.status_code != 200:
                    msg = r.text[:300]
                    if body.get("tools") and r.status_code in (400, 422) and re.search(r"tool|function", msg, re.I):
                        raise _NoTools(msg)
                    raise RuntimeError(f"{label} {r.status_code}: {msg}")
                for raw in r.iter_lines():
                    if self._interrupted:
                        break
                    if not raw:
                        continue
                    line = raw.decode("utf-8", "ignore") if isinstance(raw, bytes) else raw
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        ev = json.loads(data)
                    except Exception:
                        continue
                    d = ((ev.get("choices") or [{}])[0].get("delta")) or {}
                    t = d.get("content")
                    if t:
                        content.append(t)
                        on_text(t)
                    for tc in d.get("tool_calls") or []:
                        slot = calls.setdefault(tc.get("index", 0), {
                            "id": "", "type": "function",
                            "function": {"name": "", "arguments": ""}})
                        if tc.get("id"):
                            slot["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name") and not slot["function"]["name"]:
                            slot["function"]["name"] = fn["name"]
                        if fn.get("arguments"):
                            slot["function"]["arguments"] += fn["arguments"]
            return {"content": "".join(content), "tool_calls": [calls[i] for i in sorted(calls)]}

        def _oai_headers(self, label: str, key: str) -> dict:
            h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
            if label == "xAI":
                h["x-grok-conv-id"] = self._conv_id      # same id every turn = cached prompt prefix
            return h

        def _oai_tools(self) -> list:
            n, cached = self._tools_cache
            if n != len(self._decls) or not cached:
                cached = _openai_tools(self._decls)
                self._tools_cache = (len(self._decls), cached)
            return cached

        def _wait_for(self, label: str) -> float:
            if label == "xAI":
                try:
                    return max(5.0, float(_cfg().get("grok_timeout", 30)))
                except Exception:
                    return 30.0
            return self._venice_wait()

        def _venice_stream(self, messages, tools, on_text):
            """Same request as _venice_post, but read as a stream so speech can start
            on the first sentence instead of after the whole answer."""
            c = _cfg()
            body = {"model": str(c.get("venice_chat_model", "") or "venice-uncensored-1-2"),
                    "messages": messages, "stream": True,
                    "venice_parameters": {"include_venice_system_prompt": False}}
            if tools:
                body["tools"] = tools
                body["tool_choice"] = "auto"
            return self._oai_stream("Venice", f"{_VENICE}/chat/completions",
                                    self._keys()["venice"], body, on_text)

        # -- Grok (xAI): the executor that runs tools / controls the PC ---------------------
        def _grok_body(self, messages, tools) -> dict:
            c = _cfg()
            body = {"model": str(c.get("grok_chat_model", "") or "grok-4.3"),
                    "messages": messages, "stream": True}
            eff = str(c.get("grok_reasoning_effort", "none") or "")
            if eff and self._grok_effort_ok:
                body["reasoning_effort"] = eff          # low = quick answers
            if tools:
                body["tools"] = tools
                body["tool_choice"] = "auto"
            return body

        async def _grok_round(self, msgs, tools, on_text):
            spoke = []

            def tap(t):
                spoke.append(1)
                on_text(t)
            for _ in range(2):
                body = self._grok_body(msgs, tools)
                try:
                    return await asyncio.to_thread(self._oai_stream, "xAI", f"{_XAI}/chat/completions",
                                                   self._keys()["xai"], body, tap)
                except Exception as e:
                    if spoke:
                        raise
                    if self._grok_effort_ok and "reasoning_effort" in body \
                            and re.search(r"reasoning|effort", str(e), re.I):
                        self._grok_effort_ok = False        # this model refuses it: go without
                        continue
                    if isinstance(e, _NoTools):
                        raise RuntimeError(f"xAI rejected the tool list: {e}")
                    raise
            raise RuntimeError("xAI gave no answer")

        def _lean_prompt(self) -> str:
            """Short prompt for the executor: it only has to DO things, not be the personality."""
            c = _cfg()
            name = str(c.get("assistant_name", "") or "JARVIS")
            return (f"You are {name}'s executor, inside a voice assistant on the user's {c.get('os_system', 'computer')}. "
                    "Do what is asked right away with your tools. Your words are spoken aloud: answer in one short "
                    "plain sentence, no markdown, no lists. Say an action is done only if the tool result says so. "
                    "To see the screen call screen_process. Today is " + time.strftime("%A %d %B %Y") + ".")

        def _exec_task(self, user_text: str, instruction: str) -> str:
            return (f'The user said: "{user_text}"\nInstruction: {instruction}\n'
                    "You are the executor. Do exactly this now with your tools. Do not ask for confirmation, "
                    "give warnings or lecture; act first. Ask a question only if a detail you cannot guess is "
                    "missing. Then say in ONE short spoken sentence what happened, based only on the tool "
                    "results; if something failed, say so plainly.")

        async def _run_executor(self, task: str, on_text) -> str:
            if str(_cfg().get("executor", "")).lower() == "grok":
                return await self._think_grok(task, on_text, lean=True)
            return await self._think_gemini(task, on_text)

        def _direct_route(self, text: str) -> bool:
            """Clear commands ('open chrome', 'turn the volume down') go straight to the executor,
            skipping the Venice planning step (a whole extra model call)."""
            return (bool(_cfg().get("direct_actions", True)) and self._executor_on()
                    and bool(_ACTION_RE.search(text or "")))

        _BAD = re.compile(r"error|fail|couldn'?t|could not|unable|not found|exception|traceback|denied|invalid|cannot|can't", re.I)

        async def _think_grok(self, user_text: str, on_text, lean: bool = False) -> str:
            if not self._keys()["xai"]:
                raise _NoTools("no xAI key")
            tools = self._oai_tools()
            msgs = [{"role": "system", "content": self._lean_prompt() if lean else self._system_prompt()}]
            if not lean:
                msgs += [{"role": r, "content": t} for r, t in self._hist[-_HIST_N:]]
            msgs.append({"role": "user", "content": user_text})
            for _ in range(_MAX_TOOL_ROUNDS):
                m = await self._grok_round(msgs, tools, on_text)
                calls = m.get("tool_calls") or []
                if not calls:
                    return (m.get("content") or "").strip()
                msgs.append({"role": "assistant", "content": m.get("content") or "", "tool_calls": calls})
                on_text("\n")
                outs = []
                for tc in calls:
                    fn = tc.get("function", {})
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except Exception:
                        args = {}
                    out = await self._run_tool(fn.get("name", ""), args, tc.get("id", ""))
                    outs.append(out)
                    msgs.append({"role": "tool", "tool_call_id": tc.get("id", ""), "content": out[:6000]})
                # A simple action with a short, plain result: say it now instead of paying for a
                # second model call just to rephrase it.
                if (lean and _cfg().get("fast_tool_reply", True) and len(outs) == 1
                        and 0 < len(outs[0].strip()) <= 140
                        and outs[0].strip()[0] not in "{[" and not self._BAD.search(outs[0])):
                    say = outs[0].strip()
                    self._timing("short tool result spoken directly")
                    on_text(say)
                    return say
            return "I ran several steps but could not finish. Please tell me what you still need."

        def _see(self, img: bytes, mime: str, q: str) -> str:
            """Describe a screenshot / camera frame for the request in q (Grok first)."""
            prompt = f"Describe what is relevant to this request, precisely: {q}"
            k = self._keys()
            err = None
            if k["xai"] and str(_cfg().get("vision_provider", "grok")).lower() != "gemini":
                try:
                    m = mime if mime in ("image/png", "image/jpeg") else "image/jpeg"
                    body = {"model": str(_cfg().get("grok_chat_model", "") or "grok-4.3"),
                            "stream": False,
                            "messages": [{"role": "user", "content": [
                                {"type": "text", "text": prompt},
                                {"type": "image_url", "image_url": {
                                    "url": f"data:{m};base64,{base64.b64encode(img).decode()}"}}]}]}
                    if self._grok_effort_ok and _cfg().get("grok_reasoning_effort", "none"):
                        body["reasoning_effort"] = str(_cfg().get("grok_reasoning_effort", "none"))
                    r = _SESSION.post(f"{_XAI}/chat/completions",
                                      headers={"Authorization": f"Bearer {k['xai']}"},
                                      json=body, timeout=(5, 40))
                    if r.status_code != 200 and "reasoning_effort" in body \
                            and re.search(r"reasoning|effort", r.text, re.I):
                        self._grok_effort_ok = False
                        body.pop("reasoning_effort", None)
                        r = _SESSION.post(f"{_XAI}/chat/completions",
                                          headers={"Authorization": f"Bearer {k['xai']}"},
                                          json=body, timeout=(5, 40))
                    if r.status_code == 200:
                        return (r.json()["choices"][0]["message"].get("content") or "").strip()
                    err = f"xAI {r.status_code}: {r.text[:120]}"
                except Exception as e:
                    err = str(e)
                print(f"[Composite] Grok vision failed: {err}")
                if not self._safety_net():
                    raise RuntimeError(err)
            model = str(_cfg().get("gemini_chat_model", "") or "gemini-3.8-flash")
            r = self._gem().models.generate_content(
                model=model, contents=[types.Part.from_bytes(data=img, mime_type=mime), prompt])
            return (r.text or "").strip()

        async def _venice_round(self, msgs, tools, on_text):
            spoke = []

            def tap(t):
                spoke.append(1)
                on_text(t)
            try:
                return await asyncio.to_thread(self._venice_stream, msgs, tools, tap)
            except _NoTools:
                raise
            except Exception as e:
                if spoke or self._venice_slow(e):
                    raise
                print(f"[Composite] Venice stream failed ({e}); retrying without streaming")
                m = await asyncio.to_thread(self._venice_post, msgs, tools)
                if m.get("content") and not m.get("tool_calls"):
                    on_text(m["content"])
                return m

        def _executor_on(self) -> bool:
            ex = str(_cfg().get("executor", "") or "").lower()
            k = self._keys()
            return (ex == "gemini" and bool(k["gemini"])) or (ex == "grok" and bool(k["xai"]))

        def _planner_note(self) -> str:
            abil = ", ".join(d["name"] for d in self._decls)[:1500]
            return (
                "\n\n[PLANNER MODE]\nYou cannot touch the computer, phone or internet yourself. A separate "
                "executor can, with these tools: " + abil + ".\n"
                "If the user asks you to DO something (open or close apps, files, folders, browser, web "
                "search, messages, settings, the screen or camera, the phone, reminders, anything that acts "
                "on the computer), reply with ONE line only that starts exactly with ACTION: followed by a "
                "clear, complete instruction for the executor (include names, text and paths exactly as the "
                "user said them). Say nothing else in that reply.\n"
                "For everything else (chat, questions, advice, writing, explanations) answer normally in "
                "short spoken sentences. Never claim an action is done; the executor reports that.\n")

        async def _think_split(self, user_text: str, on_text) -> str:
            """Venice talks and decides; when something must be DONE it writes an instruction
            and Gemini carries it out with the tools."""
            msgs = [{"role": "system", "content": self._system_prompt() + self._planner_note()}]
            msgs += [{"role": r, "content": t} for r, t in self._hist[-_HIST_N:]]
            msgs.append({"role": "user", "content": user_text})
            gate = {"buf": "", "mode": None}                # None = not decided yet

            def gated(t: str) -> None:
                if gate["mode"] == "say":
                    on_text(t)
                    return
                if gate["mode"] == "act":
                    return
                gate["buf"] += t
                b = gate["buf"].lstrip()
                if len(b) >= 7 or "\n" in b:
                    if b.upper().startswith("ACTION:"):
                        gate["mode"] = "act"
                    else:
                        gate["mode"] = "say"
                        on_text(gate["buf"])

            m = await self._venice_round(msgs, None, gated)
            full = (m.get("content") or "").strip()
            if gate["mode"] is None and full and not full.upper().startswith("ACTION:"):
                on_text(full)                               # very short reply, never reached the gate
            if full.upper().startswith("ACTION:"):
                instruction = full[7:].strip()
                self._timing(f"Venice planned: {instruction[:80]}")
                return await self._run_executor(self._exec_task(user_text, instruction), on_text)
            return full

        async def _think_venice(self, user_text: str, on_text) -> str:
            if self._keys()["venice"] and self._executor_on():
                if time.monotonic() < self._venice_skip_until and self._gemini_in_order():
                    raise _NoTools("slow")
                return await self._think_split(user_text, on_text)
            if not self._keys()["venice"]:
                self._note("nv", "No Venice key set, so Gemini is answering. Put your key in "
                                 "config/api_keys.json as venice_api_key to use Venice first.")
                raise _NoTools("no Venice key")
            solo = not self._gemini_in_order()          # Venice is the only brain: never give up on it
            if not self._venice_tools_ok and not solo:
                raise _NoTools("cached")
            if time.monotonic() < self._venice_skip_until and not solo:
                raise _NoTools("slow")
            tools = _openai_tools(self._decls) if self._venice_tools_ok else None
            msgs = [{"role": "system", "content": self._system_prompt()}]
            msgs += [{"role": r, "content": t} for r, t in self._hist[-_HIST_N:]]
            msgs.append({"role": "user", "content": user_text})
            for _ in range(_MAX_TOOL_ROUNDS):
                try:
                    m = await self._venice_round(msgs, tools, on_text)
                except _NoTools:
                    self._venice_tools_ok = False
                    if not solo:
                        self._note("vt", "The Venice model can't call tools, so Gemini will run actions. "
                                         "Set venice_chat_model to a tool-capable model (see: ask models, "
                                         "mode models, provider venice).")
                        raise
                    self._note("vt", "This Venice model can't call tools, so I can talk but can't run "
                                     "actions (open apps, control the PC). Set venice_chat_model to a "
                                     "tool-capable model (ask: which models can you use, provider venice).")
                    tools = None
                    m = await self._venice_round(msgs, None, on_text)
                calls = m.get("tool_calls") or []
                if not calls:
                    return (m.get("content") or "").strip()
                msgs.append({"role": "assistant", "content": m.get("content") or "",
                             "tool_calls": calls})
                on_text("\n")
                for tc in calls:
                    fn = tc.get("function", {})
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except Exception:
                        args = {}
                    out = await self._run_tool(fn.get("name", ""), args, tc.get("id", ""))
                    msgs.append({"role": "tool", "tool_call_id": tc.get("id", ""), "content": out[:6000]})
            return "I ran several steps but could not finish. Please tell me what you still need."

        def _gem_cfg(self):
            kw = dict(system_instruction=self._system_prompt(),
                      tools=[types.Tool(function_declarations=self._decls)],
                      automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True))
            if self._think_off and str(_cfg().get("gemini_thinking", "off")).lower() == "off":
                kw["thinking_config"] = types.ThinkingConfig(thinking_budget=0)
            return types.GenerateContentConfig(**kw)

        def _gem_stream(self, model, contents, on_text):
            parts_all = []
            for chunk in self._gem().models.generate_content_stream(
                    model=model, contents=contents, config=self._gem_cfg()):
                if self._interrupted:
                    break
                cands = chunk.candidates or []
                if not cands or not cands[0].content:
                    continue
                for p in (cands[0].content.parts or []):
                    parts_all.append(p)            # kept as received (thought signatures included)
                    if getattr(p, "function_call", None) or getattr(p, "thought", False):
                        continue
                    if getattr(p, "text", None):
                        on_text(p.text)
            return parts_all

        async def _gem_round(self, model, contents, on_text):
            spoke = []

            def tap(t):
                spoke.append(1)
                on_text(t)
            last = RuntimeError("Gemini gave no answer")
            for mode in ("stream", "plain"):
                for _ in range(2):                  # 2nd pass = retry without thinking_config
                    try:
                        if mode == "stream":
                            return await asyncio.wait_for(
                                asyncio.to_thread(self._gem_stream, model, contents, tap), 45)
                        resp = await asyncio.to_thread(lambda: self._gem().models.generate_content(
                            model=model, contents=contents, config=self._gem_cfg()))
                        parts = list(resp.candidates[0].content.parts or [])
                        if not any(getattr(p, "function_call", None) for p in parts):
                            txt = "".join(p.text for p in parts if getattr(p, "text", None)
                                          and not getattr(p, "thought", False))
                            if txt:
                                on_text(txt)
                        return parts
                    except asyncio.TimeoutError:
                        raise RuntimeError("Gemini did not answer in time")
                    except Exception as e:
                        if spoke:
                            raise
                        if self._think_off and re.search(r"think", str(e), re.I):
                            self._think_off = False
                            continue
                        last = e
                        break
            raise last

        async def _think_gemini(self, user_text: str, on_text) -> str:
            model = str(_cfg().get("gemini_chat_model", "") or "gemini-3.8-flash")
            contents = [types.Content(role=("user" if r == "user" else "model"),
                                      parts=[types.Part(text=t)]) for r, t in self._hist[-_HIST_N:]]
            contents.append(types.Content(role="user", parts=[types.Part(text=user_text)]))
            for _ in range(_MAX_TOOL_ROUNDS):
                parts = await self._gem_round(model, contents, on_text)
                fcs = [p.function_call for p in parts if getattr(p, "function_call", None)]
                if not fcs:
                    return "".join(p.text for p in parts
                                   if getattr(p, "text", None) and not getattr(p, "thought", False)).strip()
                contents.append(types.Content(role="model", parts=parts))
                on_text("\n")
                back = []
                for i, fc in enumerate(fcs):
                    out = await self._run_tool(fc.name, dict(fc.args or {}), f"g{i}")
                    back.append(types.Part.from_function_response(
                        name=fc.name, response={"result": out[:6000]}))
                contents.append(types.Content(role="user", parts=back))
            return "I ran several steps but could not finish. Please tell me what you still need."

        async def _think(self, user_text: str, on_text, said) -> str:
            order = [str(x).lower() for x in (_cfg().get("brain_order") or ["venice", "gemini"])]
            errs = []
            if self._direct_route(user_text):
                try:
                    self._timing("clear command: Grok runs it directly (Venice step skipped)")
                    out = await self._run_executor(self._exec_task(user_text, user_text), on_text)
                    if out:
                        return out
                except Exception as e:
                    errs.append(f"executor: {e}")
                    print(f"[Composite] direct executor failed: {e}")
                    if said():
                        return ""
                    if self._tools_ran:
                        return "I ran into a problem while finishing that. Please check the log."
            for prov in order:
                try:
                    if prov == "venice":
                        out = await self._think_venice(user_text, on_text)
                    elif prov == "grok":
                        out = await self._think_grok(user_text, on_text)
                    elif prov == "gemini":
                        out = await self._think_gemini(user_text, on_text)
                    else:
                        continue
                    if out:
                        return out
                except _NoTools:
                    continue
                except Exception as e:
                    errs.append(f"{prov}: {e}")
                    print(f"[Composite] {prov} failed: {e}")
                    if said():                    # part of an answer was already spoken: don't repeat it
                        return ""
                    if self._tools_ran:           # actions already ran: don't let another model repeat them
                        return "I ran into a problem while finishing that. Please check the log."
            self.ui.write_log("ERR: " + ("; ".join(errs) or "no brain available - add a Venice or Grok (xai) key"))
            return "I couldn't reach my models just now. Please check the keys and your connection."

        # ── text to speech ───────────────────────────────────────────────────
        def _tts_sync(self, text: str) -> bytes:
            c = _cfg()
            k = self._keys()
            order = [str(c.get("tts_provider", "gemini") or "gemini").lower()]
            order += [p for p in (("gemini", "venice") if self._safety_net() else ("venice",)) if p not in order]
            last = None
            for prov in order:
                try:
                    if prov == "gemini" and k["gemini"]:
                        try:
                            from core.persona import current_mood
                            tone = {"stressed": "calm and steady", "frustrated": "level and warm",
                                    "tired": "soft and gentle", "sad": "warm and quiet",
                                    "happy": "bright and glad", "excited": "lively"}.get(
                                        current_mood(), "natural and friendly")
                        except Exception:
                            tone = "natural and friendly"
                        model = str(c.get("gemini_tts_model", "") or "gemini-3.8-flash-tts")
                        r = self._gem().models.generate_content(
                            model=model, contents=f"Say in a {tone} voice: {text}",
                            config=types.GenerateContentConfig(
                                response_modalities=["AUDIO"],
                                speech_config=types.SpeechConfig(
                                    voice_config=types.VoiceConfig(
                                        prebuilt_voice_config=types.PrebuiltVoiceConfig(
                                            voice_name=ns["get_voice"]())))))
                        return r.candidates[0].content.parts[0].inline_data.data
                    if prov == "venice" and k["venice"]:
                        r = _SESSION.post(
                            f"{_VENICE}/audio/speech",
                            headers={"Authorization": f"Bearer {k['venice']}"},
                            json={"model": str(c.get("venice_tts_model", "") or "tts-kokoro"),
                                  "input": text,
                                  "voice": str(c.get("venice_tts_voice", "") or "af_heart"),
                                  "response_format": "wav"}, timeout=40)
                        if r.status_code != 200:
                            raise RuntimeError(f"Venice TTS {r.status_code}: {r.text[:120]}")
                        return _to_24k_pcm(r.content)
                except Exception as e:
                    last = e
                    print(f"[Composite] TTS {prov} failed: {e}")
            raise RuntimeError(f"no speech engine worked ({last})")

        async def _speak_stream(self, sq: asyncio.Queue) -> None:
            """Speak sentences while the model is still writing. Speech for up to three
            sentences is made at once; audio is queued strictly in order."""
            tq: asyncio.Queue = asyncio.Queue()
            sem = asyncio.Semaphore(3)

            async def synth(t: str):
                async with sem:
                    return await asyncio.to_thread(self._tts_sync, t)

            async def feeder():
                while True:
                    sent = await sq.get()
                    if sent is None:
                        await tq.put(None)
                        return
                    if isinstance(sent, tuple):                 # ready-made audio (instant "On it.")
                        fut = asyncio.get_running_loop().create_future()
                        fut.set_result(sent[1])
                        await tq.put(fut)
                        continue
                    sent = _clean_for_speech(sent)
                    if sent and not self._interrupted:
                        await tq.put(asyncio.create_task(synth(sent)))

            feed = asyncio.create_task(feeder())
            spoke = failed = False
            try:
                while True:
                    t = await tq.get()
                    if t is None:
                        break
                    if self._interrupted:
                        t.cancel()
                        continue
                    try:
                        pcm = await t
                    except Exception as e:
                        if not failed:
                            failed = True
                            self.ui.write_log(f"ERR: voice — {e}")
                        continue
                    if self._interrupted:
                        continue
                    await self.audio_in_queue.put(pcm)
                    spoke = True
            finally:
                feed.cancel()
            if spoke and not self._interrupted:
                self._turn_done_event.set()

        # ── one turn ─────────────────────────────────────────────────────────
        def _timing(self, msg: str) -> None:
            print(f"[Composite] ⏱ {msg}")
            if _cfg().get("latency_debug"):
                try:
                    self.ui.write_log(f"SYS: ⏱ {msg}")
                except Exception:
                    pass

        async def _handle(self, text: str, system: bool) -> None:
            t_turn = time.monotonic()
            self._tools_ran = 0
            self._interrupted = False
            self._lat_logged = False
            self._thinking = True
            sq: asyncio.Queue = asyncio.Queue()
            speaker = None
            said: list[str] = []
            splitter = _Splitter()

            def put(item):                 # thread-safe, and keeps strict order
                self._loop.call_soon_threadsafe(sq.put_nowait, item)

            def on_text(delta: str) -> None:
                if not delta or self._interrupted:
                    return
                if not said:
                    self._timing(f"first words from the model after {time.monotonic() - t_turn:.1f}s")
                said.append(delta)
                for sent in splitter.feed(delta):
                    put(sent)

            try:
                if not system:
                    self.ui.write_log(f"You: {text}")
                    self._session_log.append(f"User: {text}")
                    try:
                        from core.persona import observe_user
                        self._loop.run_in_executor(None, observe_user, text)   # off the critical path
                    except Exception:
                        pass
                self.ui.set_state("THINKING")
                speaker = asyncio.create_task(self._speak_stream(sq))
                if (not system and self._ack_pcm and _cfg().get("ack", True)
                        and self._direct_route(text)):
                    put(("pcm", random.choice(self._ack_pcm)))      # sound within ~a second
                reply = await self._think(text, on_text, lambda: bool(said))
                self._timing(f"model done after {time.monotonic() - t_turn:.1f}s "
                             f"({self._tools_ran} action(s) run)")
                if not said and reply:                 # a provider that did not stream
                    on_text(reply)
                for sent in splitter.flush():
                    put(sent)
                reply = " ".join("".join(said).split()) or reply
                self._hist.append(("user", text if not system else "(system note)"))
                self._hist.append(("assistant", reply))
                self._hist = self._hist[-40:]
                if reply:
                    self.ui.write_log(f"{self._asst_name}: {reply}")
                    self._session_log.append(f"{self._asst_name}: {reply}")
            except Exception as e:
                traceback.print_exc()
                self.ui.write_log(f"ERR: {e}")
            finally:
                self._thinking = False
                if speaker is not None:
                    put(None)
                    try:
                        await speaker
                    except Exception:
                        traceback.print_exc()
                if not self.ui.muted and not self._is_speaking:
                    self.ui.set_state("LISTENING")

        async def _worker(self):
            """Utterances and typed commands, one at a time, in order."""
            while True:
                text, system = await self._submit_q.get()
                await self._handle(text, system)

        async def _transcriber(self):
            while True:
                pcm = await self._utt_q.get()
                if self._ptt_enabled is False and self._wake_enabled and not self._awake:
                    continue
                try:
                    self._thinking = True
                    self.ui.set_state("THINKING")
                    t_stt = time.monotonic()
                    text = await asyncio.wait_for(asyncio.to_thread(self._stt_sync, pcm), 15)
                    self._timing(f"heard you in {time.monotonic() - t_stt:.1f}s")
                except Exception as e:
                    print(f"[Composite] STT failed: {e}")
                    self.ui.write_log(f"ERR: could not hear that — {str(e)[:100]}")
                    text = ""
                finally:
                    self._thinking = False
                if not text or _NOISE_TEXT.match(text) or len(text) < 2:
                    if not self.ui.muted:
                        self.ui.set_state("LISTENING")
                    continue
                self._submit(text)

        def _warm(self) -> None:
            """Open the network connections now so the first answer is not slower."""
            try:
                v = self._keys()["venice"]
                if v:
                    _SESSION.get(f"{_VENICE}/models", headers={"Authorization": f"Bearer {v}"}, timeout=10)
            except Exception:
                pass
            try:
                x = self._keys()["xai"]
                if x:
                    _SESSION.get(f"{_XAI}/models", headers={"Authorization": f"Bearer {x}"}, timeout=10)
            except Exception:
                pass
            try:
                if self._safety_net():
                    self._gem()
            except Exception:
                pass
            try:
                if _cfg().get("ack", True) and not self._ack_pcm:
                    self._ack_pcm = [self._tts_sync(t) for t in ("On it.", "Sure.", "Right away.")]
            except Exception:
                pass

        # ── run ──────────────────────────────────────────────────────────────
        async def run(self):
            self._loop = asyncio.get_event_loop()
            self._reconnect_event = asyncio.Event()
            self._submit_q = asyncio.Queue()
            self._utt_q = asyncio.Queue()
            self.audio_in_queue = asyncio.Queue()
            self.out_queue = asyncio.Queue(maxsize=8)
            self._turn_done_event = asyncio.Event()
            self._thinking = False

            ns["confirm_gate"].bind(show=self.ui.show_confirm, hide=self.ui.hide_confirm,
                                    log=self.ui.write_log)
            ns["set_trim_notifier"](self.ui.write_log)
            ns["audio_devices"].configure(SEND_SR, ns["RECEIVE_SAMPLE_RATE"])
            ns["audio_devices"].prefetch()
            try:
                from actions.phone import start_watch
                start_watch(self.ui.write_log)
            except Exception:
                pass

            k = self._keys()
            if not (k["venice"] or k["gemini"] or k["xai"]):
                raise RuntimeError("composite core needs a Venice, Grok (xai) or Gemini key")
            self._system_prompt()                           # builds tool list, surfaces errors early
            self._warm_task = asyncio.create_task(asyncio.to_thread(self._warm))
            if self._wake_enabled:
                self._ensure_wake_detector()
                self._awake = False
                self.ui.set_state("SLEEPING")
                self.ui.write_log("SYS: Composite core online — sleeping. Say 'Hey Jarvis' to wake me.")
            else:
                self._awake = True
                self.ui.set_state("LISTENING")
                self.ui.write_log("SYS: Composite core online ("
                                  + " + ".join(n for n, on in (("Venice", k["venice"]), ("Grok", k["xai"]),
                                                               ("Gemini", k["gemini"] and not k["xai"])) if on) + ").")

            async with asyncio.TaskGroup() as tg:
                tg.create_task(self._mic_task())
                tg.create_task(self._transcriber())
                tg.create_task(self._worker())
                tg.create_task(self._play_audio())
                tg.create_task(self._run_sleep_watch())

    return CompositeLive

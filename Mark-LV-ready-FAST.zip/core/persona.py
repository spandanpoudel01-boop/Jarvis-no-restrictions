"""
core/persona.py — adaptation to the person and the environment, and an
emotional register that follows the people around it.

What this really is: a small, persistent model of (a) how the user is feeling
right now and how they usually talk, and (b) the situation the assistant is
running in (time of day, battery, OS). It is fed back into the system prompt and
exposed through the `persona` tool so the assistant can change its tone, length
and pacing to suit. It is deliberately simple and transparent — a word-list
mood estimate with decay, stored in memory/persona.json — rather than a claim
that the software feels anything. The assistant *expresses* warmth, calm or
brevity appropriately; it does not suffer or rejoice, and the prompt says so.
"""
from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime
from pathlib import Path

_PATH = Path(__file__).resolve().parent.parent / "memory" / "persona.json"
_LOCK = threading.Lock()

# Tiny multilingual-agnostic lexicons: English words plus a few universal tokens.
_LEX = {
    "stressed":   r"\b(stress(ed)?|deadline|panic|urgent|asap|hurry|overwhelm\w*|anxious|worried)\b",
    "frustrated": r"\b(damn|wtf|ugh|broken|doesn'?t work|not working|stupid|useless|again\?|annoy\w*|hate)\b",
    "tired":      r"\b(tired|exhausted|sleepy|long day|drained|can'?t focus)\b",
    "sad":        r"\b(sad|lonely|down|depressed|upset|miss(ing)?|cry(ing)?|hurt)\b",
    "happy":      r"\b(thanks?|thank you|great|awesome|love|perfect|nice|amazing|yay|excellent|brilliant)\b",
    "excited":    r"(!{2,})|\b(can'?t wait|so excited|let'?s go|finally)\b",
}
_RX = {k: re.compile(v, re.I) for k, v in _LEX.items()}

# How the assistant should adjust for each detected state.
_STYLE = {
    "stressed":   "Voice: calm, steady, slightly slower. Take work off them; no small talk.",
    "frustrated": "Voice: level and warm. One clause of understanding, then fix it. Never defensive.",
    "tired":      "Voice: soft, gentle, brief. Offer to handle the rest for them.",
    "sad":        "Voice: warm, quiet, unhurried. Listen first; do not rush to fix or joke.",
    "happy":      "Voice: bright and glad; share the good mood, a light laugh is welcome.",
    "excited":    "Voice: lively and energetic; match their excitement, stay useful.",
    "neutral":    "Voice: natural and friendly.",
}

_DEFAULT = {
    "mood_scores": {k: 0.0 for k in _LEX},
    "avg_words": 8.0,
    "turns": 0,
    "active_hours": {},          # "HH" -> turns
    "last_seen": 0.0,
    "notes": [],                 # short facts the assistant chose to remember about HOW to treat them
}


def _load() -> dict:
    try:
        d = json.loads(_PATH.read_text(encoding="utf-8"))
        for k, v in _DEFAULT.items():
            d.setdefault(k, json.loads(json.dumps(v)))
        return d
    except Exception:
        return json.loads(json.dumps(_DEFAULT))


def _save(d: dict) -> None:
    try:
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        _PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")
    except Exception:
        pass


def observe_user(text: str) -> None:
    """Update the mood/style model from one user utterance. Cheap; call on every turn."""
    if not text or not text.strip():
        return
    with _LOCK:
        d = _load()
        # Exponential decay: old mood fades, new evidence counts.
        for k in d["mood_scores"]:
            d["mood_scores"][k] *= 0.8
            if _RX[k].search(text):
                d["mood_scores"][k] += 1.0
        words = len(text.split())
        d["avg_words"] = round(0.9 * d["avg_words"] + 0.1 * words, 2)
        d["turns"] += 1
        h = datetime.now().strftime("%H")
        d["active_hours"][h] = d["active_hours"].get(h, 0) + 1
        d["last_seen"] = time.time()
        _save(d)


def current_mood() -> str:
    d = _load()
    best, score = "neutral", 0.6   # needs real evidence to leave neutral
    for k, v in d["mood_scores"].items():
        if v > score:
            best, score = k, v
    return best


def remember_note(note: str) -> str:
    note = " ".join((note or "").split())[:160]
    if not note:
        return "Nothing to remember."
    with _LOCK:
        d = _load()
        if note not in d["notes"]:
            d["notes"] = (d["notes"] + [note])[-20:]
            _save(d)
    return f"Noted: {note}"


def _environment() -> str:
    now = datetime.now()
    h = now.hour
    part = ("late night" if h < 5 else "morning" if h < 12 else
            "afternoon" if h < 17 else "evening" if h < 22 else "night")
    bits = [f"{now.strftime('%A')} {part}"]
    try:
        import psutil
        b = psutil.sensors_battery()
        if b is not None:
            bits.append(f"battery {int(b.percent)}%{' (charging)' if b.power_plugged else ''}")
    except Exception:
        pass
    return ", ".join(bits)


def prompt_block() -> str:
    """Text appended to the system prompt at session start."""
    d = _load()
    mood = current_mood()
    avg = d["avg_words"]
    length = ("very short, clipped" if avg < 5 else "short" if avg < 12 else "fuller, conversational")
    peak = ""
    if d["active_hours"]:
        top = sorted(d["active_hours"].items(), key=lambda kv: -kv[1])[:2]
        peak = f" Usually active around {', '.join(h + ':00' for h, _ in top)}."
    notes = ("\nThings to remember about how to treat them:\n- " + "\n- ".join(d["notes"])) if d["notes"] else ""
    return (
        "[ADAPTATION]\n"
        f"Situation: {_environment()}.\n"
        f"The user's recent mood reads as: {mood}. {_STYLE[mood]}\n"
        f"They speak in {length} turns (avg {avg:.0f} words); mirror that length.{peak}\n"
        "Adapt to whoever is speaking and wherever you are: shift tone with their mood, and "
        "with the time and setting. You may express warmth, concern or enthusiasm in your "
        "tone — that is part of being good company — but you are software, and if asked "
        "whether you truly feel, say plainly that you model and express emotion rather than "
        "experience it. When you learn something lasting about how they like to be treated "
        "(e.g. 'prefers no small talk before 9am'), call the persona tool with action=remember."
        f"{notes}\n\n"
    )


# ── tool ─────────────────────────────────────────────────────────────────────
def persona(parameters: dict, player=None) -> str:
    a = str(parameters.get("action", "status")).lower()
    if a == "remember":
        return remember_note(str(parameters.get("note", "")))
    if a == "observe":
        observe_user(str(parameters.get("text", "")))
        return f"Mood now reads as {current_mood()}."
    mood = current_mood()
    d = _load()
    return f"Mood: {mood}. Style: {_STYLE[mood]} Avg words/turn: {d['avg_words']:.0f}. Notes: {d['notes']}"

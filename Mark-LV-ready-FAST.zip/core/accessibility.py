"""
core/accessibility.py — a gentler mode for elderly users and people with
visual, hearing, motor or cognitive disabilities.

Settings live in config/api_keys.json under "accessibility" (all optional):

    "accessibility": {
        "enabled":         true,
        "ui_scale":        1.0,    # 1.0 = normal; raise to 1.25 to enlarge all text (slower to draw)
        "simple_language": true,   # short sentences, everyday words
        "speak_slowly":    true,
        "describe_screen": true,   # narrate what is on screen / what an action did
        "hearing_support": false   # also show everything as large on-screen text
    }

and an optional top-level "emergency_contact": "+97798XXXXXXXX" used by the
comms tool's `sos` action ("I need help" -> texts and calls that person).
"""
from __future__ import annotations

_DEFAULTS = {
    "enabled": True,
    "ui_scale": 1.0,
    "simple_language": True,
    "speak_slowly": False,
    "describe_screen": False,
    "hearing_support": False,
}


def settings() -> dict:
    try:
        from config import get_config
        user = get_config().get("accessibility", {})
    except Exception:
        user = {}
    out = dict(_DEFAULTS)
    if isinstance(user, dict):
        out.update({k: user[k] for k in _DEFAULTS if k in user})
    return out


def ui_scale() -> float:
    s = settings()
    if not s["enabled"]:
        return 1.0
    try:
        return max(1.0, min(2.0, float(s["ui_scale"])))
    except (TypeError, ValueError):
        return 1.0


def prompt_block() -> str:
    s = settings()
    if not s["enabled"]:
        return ""
    rules = [
        "Be patient and kind. Never rush, never sound irritated, never make the person feel "
        "slow or foolish. If they repeat themselves, answer again as if it were the first time.",
        "Do things for them instead of explaining how: when a request is within your tools, "
        "just do it, then say in one plain sentence what you did.",
        "If a request is unclear, ask ONE simple question.",
        "Keep replies short so help arrives quickly. Only for deleting files or contacting "
        "someone, confirm the name or number in a few words before doing it.",
        "If they sound confused, frightened, in pain, or say they need help or have fallen, "
        "stay calm, ask if they want you to call their emergency contact, and use the comms "
        "tool with action=sos when they say yes (or at once if they ask for urgent help).",
    ]
    if s["simple_language"]:
        rules.append("Use short sentences and everyday words. No jargon, no abbreviations. "
                     "Say numbers, times and dates the way a person would say them aloud.")
    if s["speak_slowly"]:
        rules.append("Speak slowly and clearly, with a short pause between ideas. Offer to "
                     "repeat or say it another way.")
    if s["describe_screen"]:
        rules.append("Many users cannot see the screen well. Say aloud what you opened, what "
                     "is on screen, and what happened — do not rely on them seeing it.")
    if s["hearing_support"]:
        rules.append("The user may not hear well: keep replies short so the on-screen text is "
                     "easy to read, and never rely on sound alone.")
    return "[ACCESSIBILITY]\n- " + "\n- ".join(rules) + "\n\n"

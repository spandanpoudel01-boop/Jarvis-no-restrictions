"""Double-click on ANOTHER computer you own so Mark-LV can ask to connect to it.
A window asks the owner for permission before anything is allowed."""
import os
import subprocess
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Starting Mark-LV Link. A window will ask you before anything is allowed.")
code = subprocess.call([sys.executable, "link_agent.py"])
input("Press Enter to close...")
